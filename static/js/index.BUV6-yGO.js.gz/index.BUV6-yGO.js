const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./index.53dbfdbc.js","./monaco-editor.D3ig2Cuf.js","../css/monaco-editor.BzWl1eyH.css","./vue.ClgfzGxZ.js","./@vue.Lfky3Lsd.js","./@vueuse.BGoRStkq.js","./vue3-sfc-loader.CoUr1SK8.js","./@turf.BNKHFK8C.js","./point-in-polygon-hao.CVtqB2KT.js","./sweepline-intersections.D78iGcFZ.js","./geojson-equality-ts.385IDfwq.js","./rbush.BUqzcF6_.js","./quickselect.cI_fw6Fh.js","./fast-deep-equal.DTdzWUWM.js","./d3-geo.B8ycIn1u.js","./d3-array.0UpHvbR7.js","./concaveman.cav_hLgU.js","./tinyqueue.DO17p3hF.js","./point-in-polygon.BrHNa-um.js","./robust-predicates.B_fjz3zs.js","./skmeans.MJb8iqXg.js","./topojson-client.C_Q_XF1Z.js","./topojson-server.BJ5ICLc2.js","./polygon-clipping.C7RG_Bzj.js","./splaytree.t-pFliWO.js","./marchingsquares.DR8wX6S2.js","./d3-voronoi.DD4zjRyK.js","./dat.gui.kzZ7KUwl.js","./element-plus.BxAyUB-x.js","./lodash-es.CiJSjksT.js","./@element-plus.NJzLU2UK.js","./@popperjs.D9SI2xQl.js","./@ctrl.r5W6hzzQ.js","./dayjs.CjuVH2vT.js","./async-validator.DKvM95Vc.js","./memoize-one.BdPwpGay.js","./normalize-wheel-es.B6fDCfyv.js","./@floating-ui.8uccrNCM.js","../css/element-plus.B2tId5af.css","./vue-router.bYO7SHUI.js","./pinia.BCCKnU4o.js","../css/index.BSpnUBgZ.css","../css/cesium.BHwS5cQ6.css","./index.3e2f8736.js","../css/index.Di1jRTH3.css"])))=>i.map(i=>d[i]);
var ge=Object.defineProperty;var pe=(s,e,t)=>e in s?ge(s,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):s[e]=t;var a=(s,e,t)=>pe(s,typeof e!="symbol"?e+"":e,t);import"./vue.ClgfzGxZ.js";/* empty css               */import{E as fe,i as ve,z as we}from"./element-plus.BxAyUB-x.js";import{d as X,M as ye,O as T,u as L,ai as H,o as M,U as C,c as P,a as b,I as re,b as O,j as _e,J as Ce,F as xe,a8 as Se,P as W,V as j,au as Le}from"./@vue.Lfky3Lsd.js";import{c as Me}from"./pinia.BCCKnU4o.js";import{_ as se}from"./monaco-editor.D3ig2Cuf.js";import{c as be,a as Ae}from"./vue-router.bYO7SHUI.js";import{Q as Re,u as Pe,z as Ue,R as Te}from"./@element-plus.NJzLU2UK.js";import{d as De}from"./dat.gui.kzZ7KUwl.js";import"./lodash-es.CiJSjksT.js";import"./@vueuse.BGoRStkq.js";import"./@popperjs.D9SI2xQl.js";import"./@ctrl.r5W6hzzQ.js";import"./dayjs.CjuVH2vT.js";import"./@turf.BNKHFK8C.js";import"./point-in-polygon-hao.CVtqB2KT.js";import"./sweepline-intersections.D78iGcFZ.js";import"./geojson-equality-ts.385IDfwq.js";import"./rbush.BUqzcF6_.js";import"./quickselect.cI_fw6Fh.js";import"./fast-deep-equal.DTdzWUWM.js";import"./d3-geo.B8ycIn1u.js";import"./d3-array.0UpHvbR7.js";import"./concaveman.cav_hLgU.js";import"./tinyqueue.DO17p3hF.js";import"./point-in-polygon.BrHNa-um.js";import"./robust-predicates.B_fjz3zs.js";import"./skmeans.MJb8iqXg.js";import"./topojson-client.C_Q_XF1Z.js";import"./topojson-server.BJ5ICLc2.js";import"./polygon-clipping.C7RG_Bzj.js";import"./splaytree.t-pFliWO.js";import"./marchingsquares.DR8wX6S2.js";import"./d3-voronoi.DD4zjRyK.js";import"./async-validator.DKvM95Vc.js";import"./memoize-one.BdPwpGay.js";import"./normalize-wheel-es.B6fDCfyv.js";import"./@floating-ui.8uccrNCM.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))r(o);new MutationObserver(o=>{for(const i of o)if(i.type==="childList")for(const n of i.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&r(n)}).observe(document,{childList:!0,subtree:!0});function t(o){const i={};return o.integrity&&(i.integrity=o.integrity),o.referrerPolicy&&(i.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?i.credentials="include":o.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function r(o){if(o.ep)return;o.ep=!0;const i=t(o);fetch(o.href,i)}})();const Be=X({__name:"App",setup(s){const e="production",r="https://cesium.com/downloads/cesiumjs/releases/1.120/Build/Cesium/";return window.CESIUM_BASE_URL=r,console.log(`模式: ${e}, CESIUM_BASE_URL: ${r}`),(o,i)=>{const n=H("router-view");return M(),ye(L(fe),{size:"default"},{default:T(()=>[C(n)]),_:1})}}}),ne=(s,e)=>{const t=s.__vccOpts||s;for(const[r,o]of e)t[r]=o;return t},ke=ne(Be,[["__scopeId","data-v-6ec92aea"]]),Ee=Me();function ze(s){s.use(Ee)}const Ie=()=>se(()=>import("./index.53dbfdbc.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42]),import.meta.url),Fe=()=>se(()=>import("./index.3e2f8736.js"),__vite__mapDeps([43,3,4,40,28,29,5,30,31,32,33,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,34,35,36,37,38,1,2,39,27,44,42]),import.meta.url),Ne=[{path:"/",redirect:"/examples"},{path:"/examples",component:Fe,name:"examples"},{path:"/examples/preview",component:Ie,name:"preview"}],Oe=be({history:Ae(),routes:Ne,scrollBehavior:()=>({left:0,top:0})}),We=X({name:"IconSvg",props:{value:{type:String,required:!0}}}),je={key:0,class:"com-icon"},Ge={class:"com-icon-svg","aria-hidden":"true"},Ve=["xlink:href"];function He(s,e,t,r,o,i){return s.value.indexOf("#")===0?(M(),P("i",je,[(M(),P("svg",Ge,[b("use",{"xlink:href":s.value},null,8,Ve)]))])):(M(),P("i",{key:1,class:re(s.value)},null,2))}const Xe=ne(We,[["render",He],["__scopeId","data-v-f8504d79"]]);let G;function ae(){return{getMainViewer:()=>new Promise(t=>{const r=setInterval(()=>{G&&(clearInterval(r),t(G))},10)}),setMainViewer:t=>{G=t}}}const D=window.Cesium,Ze=`
  uniform sampler2D colorTexture;
  uniform bool showLightning;
  in vec2 v_textureCoordinates;
  

  float rand(float x)
  {
    return fract(sin(x)*75154.32912);
  }

  // 使用Perlin噪声生成3D伪随机噪声
  float rand3d(vec3 x)
  {
    return fract(375.10297*sin(dot(x,vec3(103.0139,227.0595,31.05914))));
  }
  // 生成1D Perlin噪声
  float noise(float x)
  {
    float i=floor(x);
    float a=rand(i),b=rand(i+1.);
    float f=x-i;
    return mix(a,b,f);
  }

  // 结合多个1D Perlin噪声的八度
  float perlin(float x)
  {
    float r=0.,s=1.,w=1.;
    for(int i=0;i<6;i++){
      s*=2.;
      w*=.5;
      r+=w*noise(s*x);
    }
    return r;
  }
  // 生成3D Perlin噪声
  float noise3d(vec3 x)
  {
    vec3 i=floor(x);
    float i000=rand3d(i+vec3(0.,0.,0.)),i001=rand3d(i+vec3(0.,0.,1.));
    float i010=rand3d(i+vec3(0.,1.,0.)),i011=rand3d(i+vec3(0.,1.,1.));
    float i100=rand3d(i+vec3(1.,0.,0.)),i101=rand3d(i+vec3(1.,0.,1.));
    float i110=rand3d(i+vec3(1.,1.,0.)),i111=rand3d(i+vec3(1.,1.,1.));
    vec3 f=x-i;
    return mix(mix(mix(i000,i001,f.z),mix(i010,i011,f.z),f.y),
    mix(mix(i100,i101,f.z),mix(i110,i111,f.z),f.y),f.x);
  }

  // 结合多个3D Perlin噪声的八度
  float perlin3d(vec3 x)
  {
    float r=0.;
    float w=1.,s=1.;
    for(int i=0;i<5;i++){
      w*=.5;
      s*=2.;
      r+=w*noise3d(s*x);
    }
    return r;
  }

  // 基于Perlin噪声生成闪电形状
  float f(float y)
  {
    float w=.4;// 走向宽度
    return w*(perlin(2.*y)-.5);
  }

  // 绘制闪电，可选择增加厚度
  float plot(vec2 p,float d,bool thicker)
  {
    if(thicker)d+=5.*abs(f(p.y+.001)-f(p.y));
    return smoothstep(d,0.,abs(f(p.y)-p.x));
  }

  // 基于3D Perlin噪声生成云效果
  float cloud(vec2 uv,float speed,float scale,float cover)
  {
    float iTime=czm_frameNumber*.008;
    float c=perlin3d(vec3(uv*scale,iTime*speed*2.));
    return max(0.,c-(1.-cover));
  }

  vec3 render(vec2 uv)
  {
    float iTime=czm_frameNumber*.008;
    float x=iTime+.1;
    float m=.25;// 闪电形状持续时间
    float i=floor(x/m);
    float f=x/m-i;
    float k=.4;// 闪电间隔/频率
    float n=noise(i);
    float t=ceil(n-k);
    float d=max(0.,n-k)/(1.-k);
    float o=ceil(t-f-(1.-d));
    float gt=.1;
    float go=ceil(t-f-(1.-gt));

    float lightning=0.;
    float light=0.;
    float glare=0.;
    if(o==1.){
      vec2 uv2=uv;
      uv2.y+=i*2.;
      float p=(noise(i+10.)-.5)*2.;
      uv2.x-=p;

      float strike=plot(uv2,.01,true);
      float glow=plot(uv2,.04,false);
      float glow2=plot(uv2,1.5,false);

      lightning=strike*.4+glow*.15;

      float h=noise(i+5.);
      lightning*=smoothstep(h,h+.05,uv.y+perlin(1.2*uv.x+4.*h)*.03);
      lightning+=glow2*.3;
      light=smoothstep(5.,0.,abs(uv.x-p));
      glare=go*light;
    }

    vec3 clouds=
    vec3(.5,.7,1.)*mix(.6,.9,cloud(uv,.2,.1,1.))+
    vec3(.7,.8,1.)*.6*cloud(uv*vec2(.5,1.),.06,.8,.8)+
    vec3(.9,.9,1.)*.3*cloud(uv*vec2(.1,1.),.08,5.5,.6)+
    vec3(1.,1.,1.)*.4*cloud(uv*vec2(.1,1.),.07,10.,.5);

    vec3 background=vec3(.8);//背景颜色
    background*=(.2+light*.5);
    if(showLightning == true){
      return vec3(background+lightning+glare);
    }else {
      return vec3(background+glare);
    }
    
  }

  void main()
  {
    vec2 iResolution=czm_viewport.zw;
    vec2 uv=(gl_FragCoord.xy*2.-iResolution.xy)/iResolution.y;

    out_FragColor=vec4(render(uv),1.);

    vec4 sceneColor=texture(colorTexture,v_textureCoordinates);
    out_FragColor=mix(out_FragColor,sceneColor,.5);
  }
`;class Ye{constructor(e){a(this,"_viewer");a(this,"showLightning",!1);a(this,"_lighting");this._viewer=e}init(){this._lighting=new D.PostProcessStage({name:"weather_lighting",fragmentShader:Ze,uniforms:{fogByDistance:new D.Cartesian4(10,0,1e3,.8),fogColor:D.Color.WHITE,showLightning:()=>this.showLightning}}),this._viewer.scene.postProcessStages.add(this._lighting),this._viewer.scene.postRender.addEventListener(()=>{const e=D.Math.toDegrees(this._viewer.camera.pitch);this.showLightning=e>-15})}destroy(){var e;this.clear(),(e=this._lighting)==null||e.destroy()}clear(){!this._viewer||!this._lighting||this._viewer.scene.postProcessStages.remove(this._lighting)}show(e){e?this.init():this.clear()}}const B=window.Cesium;class Je{constructor(e,t){a(this,"viewer");a(this,"angle");a(this,"size");a(this,"speed");a(this,"rainStage");if(!e)throw new Error("no viewer object!");t=t||{},this.angle=B.defaultValue(t.angle,-.6),this.size=B.defaultValue(t.size,.1),this.speed=B.defaultValue(t.speed,1e3),this.viewer=e,this.init()}show(e){this.rainStage.enabled=e}init(){this.rainStage=new B.PostProcessStage({name:"czml_rain",fragmentShader:this.rain(),uniforms:{angle:()=>this.angle,size:()=>this.size,speed:()=>this.speed}}),this.viewer.scene.postProcessStages.add(this.rainStage)}destroy(){!this.viewer||!this.rainStage||this.viewer.scene.postProcessStages.remove(this.rainStage)}rain(){return`uniform sampler2D colorTexture;
              varying vec2 v_textureCoordinates;
              uniform float angle;
              uniform float size;
              uniform float speed;
              float hash(float x){
                  return fract(sin(x*133.3)*13.13);
          }
          void main(void){
              float time = czm_frameNumber / speed;
              vec2 resolution = czm_viewport.zw;
              vec2 uv=(gl_FragCoord.xy*2.-resolution.xy)/min(resolution.x,resolution.y);
              vec3 c=vec3(.6,.7,.8);
              float a=angle;
              float si=sin(a),co=cos(a);
              uv*=mat2(co,-si,si,co);
              uv*=length(uv+vec2(0,4.9))*size + 1.;
              float v=1.-sin(hash(floor(uv.x*100.))*2.);
              float b=clamp(abs(sin(20.*time*v+uv.y*(5./(2.+v))))-.95,0.,1.)*20.;
              c*=v*b; 
              gl_FragColor = mix(texture2D(colorTexture, v_textureCoordinates), vec4(c,1), 0.5);  
          }
           `}}const qe=window.Cesium.Cartesian4,Ke=window.Cesium.Color,Qe=window.Cesium.PostProcessStage;class $e{constructor(e){a(this,"viewer");a(this,"collection");a(this,"postProcessState");a(this,"_fogByDistance",{near:100,nearValue:.35,far:4e3,farValue:.9});a(this,"_color",new Ke(1,1,1,1));a(this,"_visibility",.4);this.viewer=e,this.collection=e.scene.postProcessStages}set fogByDistance(e){this._fogByDistance=e}get fogByDistance(){return this._fogByDistance}set color(e){this._color=e}get color(){return this._color}get visibility(){return this._visibility}set visibility(e){this._visibility=e}_createPostProcessStage(){var e,t,r,o;this.postProcessState=new Qe({name:"czm_fog",fragmentShader:this._getFs(),uniforms:{fogColor:()=>this._color,visibility:()=>this._visibility,fogByDistance:new qe(((e=this._fogByDistance)==null?void 0:e.near)||10,((t=this._fogByDistance)==null?void 0:t.nearValue)||0,((r=this._fogByDistance)==null?void 0:r.far)||200,((o=this._fogByDistance)==null?void 0:o.farValue)||1)}}),this.collection.add(this.postProcessState)}_getFs(){return`float getDistance(sampler2D depthTexture, vec2 texCoords)
              {
                  float depth = czm_unpackDepth(texture(depthTexture, texCoords));
                  if (depth == 0.0) {
                      return czm_infinity;
                  }
                  vec4 eyeCoordinate = czm_windowToEyeCoordinates(gl_FragCoord.xy, depth);
                  return -eyeCoordinate.z / eyeCoordinate.w;
              }
              //根据距离，在中间进行插值
              float interpolateByDistance(vec4 nearFarScalar, float distance)
              {
                  //根据常识，雾应该是距离远，越看不清，近距离内的物体可以看清
                  //因此近距离alpha=0，远距离的alpha=1.0
                  //本例中设置可见度为200米
                  //雾特效的起始距离
                  float startDistance = nearFarScalar.x;
                  //雾特效的起始alpha值
                  float startValue = nearFarScalar.y;
                  //雾特效的结束距离
                  float endDistance = nearFarScalar.z;
                  //雾特效的结束alpha值
                  float endValue = nearFarScalar.w;
                  //根据每段距离占总长度的占比，插值alpha，距离越远，alpha值越大。插值范围0,1。
                  float t = clamp((distance - startDistance) / (endDistance - startDistance), 0.0, 1.0);
                  return mix(startValue, endValue, t);
              }
              vec4 alphaBlend(vec4 sourceColor, vec4 destinationColor)
              {
                  return sourceColor * vec4(sourceColor.aaa, 1.0) + destinationColor * (1.0 - sourceColor.a);
              }
              uniform sampler2D colorTexture;
              uniform sampler2D depthTexture;
              uniform vec4 fogByDistance;
              uniform vec4 fogColor;
              in vec2 v_textureCoordinates;
              void main(void)
              {
                  //获取地物距相机的距离
                  float distance = getDistance(depthTexture, v_textureCoordinates);
                  //获取场景原本的纹理颜色
                  vec4 sceneColor = texture(colorTexture, v_textureCoordinates);
                  //根据距离，对alpha进行插值
                  float blendAmount = interpolateByDistance(fogByDistance, distance);
                  //将alpha变化值代入雾的原始颜色中，并将雾与场景原始纹理进行融合
                  vec4 finalFogColor = vec4(fogColor.rgb, fogColor.a * blendAmount);
                  out_FragColor = alphaBlend(finalFogColor, sceneColor);
              }`}open(){const e=this.viewer.scene;this.postProcessState||(this._createPostProcessStage(),e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.7,e.fog.density=5e-4,e.fog.minimumBrightness=.03)}close(){const e=this.viewer.scene;this.postProcessState&&(this.collection.remove(this.postProcessState),this.postProcessState=void 0,e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.4,e.fog.density=2e-4,e.fog.minimumBrightness=.03)}}const et=window.Cesium.PostProcessStage;class tt{constructor(e){a(this,"viewer");a(this,"collection");a(this,"speed",80);a(this,"size",.02);a(this,"postProcessState");this.viewer=e,this.collection=e.scene.postProcessStages}_createPostProcessStage(){this.postProcessState=new et({name:"czm_snow",fragmentShader:this._getFs(),uniforms:{speed:()=>this.speed,size:()=>this.size}}),this.collection.add(this.postProcessState)}_getFs(){return`uniform sampler2D colorTexture;
    varying vec2 v_textureCoordinates;
    uniform float speed;
    uniform float size;
    float snow(vec2 uv,float scale)
    {
        float time = czm_frameNumber / speed;
        float w=smoothstep(1.,0.,-uv.y*(scale/10.));if(w<.1)return 0.;
        uv+=time/scale;uv.y+=time*2./scale;uv.x+=sin(uv.y+time*.5)/scale;
        uv*=scale;vec2 s=floor(uv),f=fract(uv),p;float k=3.,d;
        p=.5+.35*sin(11.*fract(sin((s+p+scale)*mat2(7,3,6,5))*5.))-f;d=length(p);k=min(d,k);
        k=smoothstep(0.,k,sin(f.x+f.y)*size);
        return k*w;
    }
    void main(void){
        vec2 resolution = czm_viewport.zw;
        vec2 uv=(gl_FragCoord.xy*2.-resolution.xy)/min(resolution.x,resolution.y);
        vec3 finalColor=vec3(0);
        float c = 0.0;
        c+=snow(uv,30.)*.0;
        c+=snow(uv,20.)*.0;
        c+=snow(uv,15.)*.0;
        c+=snow(uv,10.);
        c+=snow(uv,8.);
        c+=snow(uv,6.);
        c+=snow(uv,5.);
        finalColor=(vec3(c)); 
        gl_FragColor = mix(texture2D(colorTexture, v_textureCoordinates), vec4(finalColor,1), 0.5); 
    }
`}open(){const e=this.viewer.scene;this.postProcessState||(this._createPostProcessStage(),e.skyAtmosphere.hueShift=-.8,e.skyAtmosphere.saturationShift=-.7,e.skyAtmosphere.brightnessShift=-.33,e.fog.density=.001,e.fog.minimumBrightness=.8)}close(){const e=this.viewer.scene;this.postProcessState&&(this.collection.remove(this.postProcessState),this.postProcessState=void 0,e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.4,e.fog.density=2e-4,e.fog.minimumBrightness=.03)}}const it="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAYCAYAAADH2bwQAAAAAXNSR0IArs4c6QAAATlJREFUOE9t0jFLllEYxvHfJb5JOARCkUJDQkSLQ07tDeESDk5+AAdBw4IEC4qMhiAyqA8QLQ21Rq1+ghrcqy3BJRsE6cSJR3mf531uOJzh/Lnu+77OFUNVSjmLOzhO8rw+pQOsYg4/kjxtAaWU61jBH2wnOegCm7iMd0l2T5T/tyilzOI+Duud5LgLLOIWviT5MDzXicI9XMFOkr0WUEoZwyuM426SOuRppZQyiRf4naQqtaoCF/AEv5I87AMu4QF+JtnuA85XY7CfpIIjLar/L3GUZG0EaIyqW0xgY2SLBtjAVbxO8q3PqNtYwOckH/uA6mL1oP7gVpK/rb9o2jzGRbxJ8rUPuIklfMezJKWbhzOoKlP4hHN4343cNawPRfFRF7iBZQyaGXa6wDTmmzODty2gk/AKD/4B12Z3rk70mscAAAAASUVORK5CYII=",ot="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAYAAABXuSs3AAAAAXNSR0IArs4c6QAABY1JREFUaEPtWG1Mm1UUfk4FUb7KgH2wjfI5PsLX4mKWLBr1x3646TTqD2OWOSMZNupQo3GJLmuzaGY0WUBNN8Woy2L2Q41OR0z846JZshjJYBI+Bi2UfbAB0haYw0GvOe0tvC3v+/altOKS3T+8Kfee+9xzn/Occw/hFh10i+LGbeCRN3f09Jka/q3hgS3nE3GrCfP4he9/sDHgDY89Gvgb75Ew4M6vv3Ex2OKnniyKN2i2lxDgR0+drqkfHWhn8y25eXUN27fGnS5xAS6EMAEwA8gAkDrwY2tj/vCVF4gA9+q8I4WPbGsCcB3ABAAvEfmXegtLAi6ESAGwBkA2AAYfGK7jX520TPrW8rc7PfNy0c5ndiiAMui/AAwT0XSsB4gJuBCC160DsErSTQCYAuD59pezRTs6/zgD4Q/aJpM4WbVpyxMPbmbOZwFIU6y5BuASEfH6RY1FA5deLgFwNwDecEzpvZ5PP7MVT/gOKFE40zLt5Q3PB9RFcUs58gB/A+hfrPcXBVwIwWA3AEgGcINZQUTM3bnR97HDVTA1WSgCZwoOd1rGQOmL1jB1EUKkAuDf7gJwE8AFIuJDGBqGgUtPlUvQPumlsCD78Ph3NXuGutvJH6JJEIMgk/gkv6Lu5Z2Ph6mLDGq+vUwJvseo5w0Bl5yulPRg0H1qvOw63GQr9nnDaBJynzPTbK98tXFBMpK2SyV49niXEc4bBb4ewGpJDzasKme9hz5wFUz5CoPUD0QmkzrwNZhuHijb97pqMpKeZ8cwba4S0cVofIkKXFKkShrqjuR0aAPHsRPVz3V1dCCoOCHY80wnEp9X1tZadz39pxooyfkK+b/OaJQxArwAQC6AUSIa1PJE58F3bCVejypNgjdA6Ddn2av2v6VZuwghDO0l71L7UuQV1knZ0vVC936bq8DnKQSnS0mP0DcRsQxiMNM8UHHQrlm7KG6XT9qul2F1PS6EWMF1EqdqIurVOqLDcaz62c7fO0hBE1U6EIkvq+6ttVp3qdIloEBCsHKlA3AS0bjWntGAWwCsBHCRiK5q0mTf27ai8VENmihWCaA/O9tec+hdPbqwCLAYjBCRO1bgHCycollfJ7WMdL32hqvAM14oVVtXEAbN2QOVh9/Xowt7m70+RUTdsQJnficB6CAizm4LRlOTo7q+7WyYmvyUlAxrSiq4AnPcuI6HZpVLSbRs2lzb2GjVUhfOyrUAZoioPVbg98jAbNNKCudfesVWPDZyIFTZc1Stz8qFh4MUQMnsLDq8YwgGahCGMyfHXvNRsypdZELifQURtSUMOHqH94IE19uSKQI40gxMcynD9eAKYPee8P0FNaJsTbNqAAcDfMnAo1IF7pG1mJ4ZUtbjcPUDP7cCdyQBWx8GLJL+QaR+pCTlw7LysgbwuFDFUHCi98qvINynG5VzN4LfUJZ3v9ZcIURcgtOQHC6gi94JdGjCy4QQcZHDUAKaJKIeTTxqdFGfrEsTCTwuCYjfkYZSviG6iKg0YQXlgm5pKV96wFjhE6kuqpGnrSaL2stIX8VoWYueoXUwJXGKnnvtR2CPpib8lItfWSs9YeghoUsXHZok5CEhgXNSiPp001UXDTVJ6NNNgufA0X0s69DFD/+MBeX5l5T0SfhjeT6bR29PqNJFhSb/WXtCAZ49r9kQQt/wXghF7RK4rnk1WZaGkAK8Zgtu++iEudUz1aVQF/+2rLTKU7kZ3mVtwUVwVLXpaXZea/H5/Rt5bqbJdM5bvKpesW75mp6RuSWyzbzRPba7/Z+bb/K8ujuT3ztnyfnif9Vm1qxd5pMR1NTEUBUZZVLUvkrMm3Cpy0OnhI3ZtpGUH7NxVhcepeovnZjtyoWJ8zjThUdE0lkq4ND6xAGPF0INO7eBJ9jBC8z/C+8LjE3U8aGyAAAAAElFTkSuQmCC",rt="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAYCAYAAADH2bwQAAAAAXNSR0IArs4c6QAAAS1JREFUOE990qFrVlEYB+DnN1EwDIO2JRf0H7AYDNq0uLaFgRa7YnAGg4rCxKBhTRBMGwzGBsJgUYxiFCyC2GyfRvGV8+3e8W1+d7ece899OOc97/lF91TVDVzDWpJv/XwmwE00NMLjJL/bv0kwg7u4iI9J3h0C7aOqzuFJe8XDJKODFSa2uoNLeJ9kZxq4gPv4keTpNHACr9HGe/+BrpYHmMerIXAbl/F2CCx2TdsYAgu4ju0hsISrWB8CfS/eDIEVnMfLaX042Y6H8d0c18nvSZ5NA8u4gt0kW4dAVZ3GKk7hUZKfR0Efmi9JWh37gamqdu4Ws1tdcat97HrwHGe7TOwl2TzIZFU1tNZdb5v/MO5g8me8RVWdwQv8wmd8wtckf3swi7nJyX75Nv4D8ft3lTEQxGsAAAAASUVORK5CYII=",st={class:"bottomTool"},nt=["onClick"],h=window.Cesium,at=X({__name:"index",setup(s){const{getMainViewer:e}=ae();let t=null,r=0;const o=O("rotatez-t"),i=O(""),n=O([{name:"主页",icon:"iconfont-ms icon-zhuye"},{name:"放大",icon:"el-icon-zoom-in"},{name:"缩小",icon:"el-icon-zoom-out"}]);_e(async()=>{t=await e(),g()});const l=d=>{const c=t;d.name==="放大"?w(c):d.name==="缩小"?Y(c):d.name==="主页"&&c.camera.flyTo({destination:c.initCamera.position.clone(),orientation:{heading:c.initCamera.heading,pitch:c.initCamera.pitch,roll:c.initCamera.roll},duration:.8})},g=()=>{r&&r(r),r=setTimeout(()=>{t.scene.postRender.addEventListener(()=>{const d=h.Math.toDegrees(t.camera.heading),c=90-h.Math.toDegrees(t.camera.pitch);i.value="transform: rotateX("+c+"deg) rotateZ("+d+"deg)"})},3500)},p=()=>{const d=t.scene,c=t.camera;let u=new h.Cartesian3;if(t.trackedEntity)u=t.trackedEntity.position.getValue(t.clock.currentTime,u);else{const v=new h.Ray(c.positionWC.clone(),c.directionWC.clone());u=d.globe.pick(v,d,u)}u?c.flyToBoundingSphere(new h.BoundingSphere(u,0),{offset:new h.HeadingPitchRange(0,c.pitch,h.Cartesian3.distance(c.position,u)),duration:1}):c.flyTo({destination:c.position,orientation:{heading:0,pitch:c.pitch,roll:c.roll}})},w=d=>{const c=d.scene,u=d.camera,v=c.screenSpaceCameraController;if(c.mode===h.SceneMode.MORPHING||!v.enableInputs||c.mode===h.SceneMode.COLUMBUS_VIEW)return!0;if(c.mode===h.SceneMode.SCENE2D)u.zoomIn(u.positionCartographic.height*.5);else if(c.mode===h.SceneMode.SCENE3D){const y=N(c),x=F(u,y,1/2);u.flyTo({destination:x,orientation:{heading:u.heading,pitch:u.pitch,roll:u.roll},duration:.5})}},Y=d=>{const{camera:c,scene:u}=d,v=u.screenSpaceCameraController;if(u.mode===h.SceneMode.MORPHING||!v.enableInputs||u.mode===h.SceneMode.COLUMBUS_VIEW)return!0;if(u.mode===h.SceneMode.SCENE2D)c.zoomOut(c.positionCartographic.height);else if(u.mode===h.SceneMode.SCENE3D){const y=N(u),x=F(c,y,-1);c.flyTo({destination:x,orientation:{heading:c.heading,pitch:c.pitch,roll:c.roll},duration:.5,convert:!1})}},F=(d,c,u)=>{const v=new h.Cartesian3,y=h.Cartesian3.subtract(c,d.position,v),x=h.Cartesian3.multiplyByScalar(y,u,v);return h.Cartesian3.add(d.position,x,v)},N=d=>{const c=new h.Ray(d.camera.positionWC,d.camera.directionWC),u=h.IntersectionTests.rayEllipsoid(c,h.Ellipsoid.WGS84);return u?h.Ray.getPoint(c,u.start):h.IntersectionTests.grazingAltitudeLocation(c,h.Ellipsoid.WGS84)};return(d,c)=>{const u=H("el-tooltip"),v=H("el-icon");return M(),P("div",st,[b("div",{style:Ce(L(i)),class:"zhinan",onClick:p},[c[0]||(c[0]=b("img",{src:it,class:"left"},null,-1)),C(u,{class:"item",effect:"light",content:"指北针",placement:"left","popper-class":"draw_share_atooltip"},{default:T(()=>[b("img",{src:ot,class:re([L(o),"compass"])},null,2)]),_:1}),c[1]||(c[1]=b("img",{src:rt,class:"right"},null,-1))],4),b("ul",null,[(M(!0),P(xe,null,Se(L(n),(y,x)=>(M(),P("li",{key:x,onClick:$t=>l(y)},[W(C(v,null,{default:T(()=>[C(L(Re))]),_:2},1536),[[j,y.name==="主页"]]),W(C(v,null,{default:T(()=>[C(L(Pe))]),_:2},1536),[[j,y.name==="放大"]]),W(C(v,null,{default:T(()=>[C(L(Ue))]),_:2},1536),[[j,y.name==="缩小"]])],8,nt))),128))])])}}}),ct=(s,e,t)=>{const r=document.createElement(s);return r.className=e,r},lt=window.Cesium.Cartesian3,ut=window.Cesium.SceneTransforms,mt=window.Cesium.ScreenSpaceEventHandler,J=window.Cesium.ScreenSpaceEventType;class ht{constructor(e){a(this,"position",{longitude:0,latitude:0});a(this,"viewer");a(this,"_wrapper");a(this,"_enable",!1);a(this,"content","");a(this,"type","Tooltip");a(this,"handler",new mt);this.viewer=e,this._wrapper=ct("div","gd-map-tool-tip")}get enable(){return this._enable}set enable(e){this._enable!==e&&(this._enable=e,this._enableHook&&this._enableHook())}_enableHook(){this._enable?(!this._wrapper.parentNode&&this.viewer.container.appendChild(this._wrapper),this._bindEvent()):(this._unbindEvent(),this._wrapper.parentNode&&this.viewer.container.removeChild(this._wrapper))}_postRenderEvent(){this.position.latitude===0&&this.position.longitude===0||this._enable&&this.showAt(this.position,this.content)}_bindEvent(){this.viewer.scene.postRender.addEventListener(this._postRenderEvent,this),this.handler.setInputAction(e=>{this._updateWindowCoord(e.endPosition)},J.MOUSE_MOVE)}_unbindEvent(){this.viewer.scene.postRender.removeEventListener(this._postRenderEvent,this),this.handler.removeInputAction(J.MOUSE_MOVE)}_updateWindowCoord(e){const t=e.x+20,r=e.y-this._wrapper.offsetHeight/2-5;this._wrapper.style.cssText=`
    visibility:visible;
    z-index:1;
    transform:translate3d(${Math.round(t)}px,${Math.round(r)}px, 0);
    `}_getWindowPosition(e){const t=lt.fromDegrees(e.longitude,e.latitude,e.height);return ut.wgs84ToWindowCoordinates(this.viewer.scene,t)}showAt(e,t){this.position=e;const r=this._getWindowPosition(e);return r&&this._updateWindowCoord(r),this.setContent(t),this}hide(){this._enable=!1,this._wrapper&&(this._wrapper.style.cssText="visibility:hidden;")}setContent(e){const t=this._wrapper;if(typeof e=="string")this._wrapper.innerHTML=e;else if(e instanceof Element){for(;this._wrapper.hasChildNodes();)t.firstChild&&t.removeChild(t.firstChild);t.appendChild(e)}return this.content=e,this}}const m=window.Cesium,_=m,dt=`
    uniform samplerCube u_cubeMap;
    varying vec3 v_texCoord;
    void main()
    {
      vec4 color = textureCube(u_cubeMap, normalize(v_texCoord));
      gl_FragColor = vec4(czm_gammaCorrect(color).rgb, czm_morphTime);
    }
  `,gt=`
    attribute vec3 position; 
    varying vec3 v_texCoord;
    uniform mat3 u_rotateMatrix;
    void main()
    {
      vec3 p = czm_viewRotation * u_rotateMatrix * (czm_temeToPseudoFixed * (czm_entireFrustum.y * position));
      gl_Position = czm_projection * vec4(p, 1.0);
      v_texCoord = position.xyz;
    }
  `;class pt{constructor(e,t){a(this,"viewer");a(this,"sources");a(this,"show");a(this,"_sources");a(this,"_command");a(this,"_cubeMap");a(this,"defaultSkyBox");a(this,"skyListener");a(this,"_useHdr");a(this,"_attributeLocations");this.viewer=e,this.sources=t.sources,this._sources=void 0,this.show=m.defaultValue(t.show,!0);const r=_.DrawCommand;this._command=new r({modelMatrix:m.Matrix4.clone(m.Matrix4.IDENTITY),owner:this}),this._cubeMap=void 0,this._attributeLocations=void 0,this._useHdr=void 0,this.skyListener=null,this.defaultSkyBox=e.scene.skyBox}renderer(e){this.skyListener=()=>{const t=this.viewer.scene.camera.positionCartographic.height,r=22e4,o=15e4,i=12e4,n=1e4,l=this.viewer.scene.skyAtmosphere;if(t<r&&m.defined(e)){let p=(t-i)/(r-i);p>1?p=1:p<0&&(p=0);let w=(t-i)/(o-i);w>1?w=1:w<0&&(w=0),e.alpha=1-w,t>i?(l.show=!0,l.alpha=p,this.viewer.scene.skyBox=e):this.viewer.scene.skyAtmosphere.show=!1}else l.alpha=1,this.viewer.scene.skyBox=this.defaultSkyBox;const g=this.viewer.scene.screenSpaceCameraController;if(this.viewer.scene.skyBox!==this.defaultSkyBox)t>i-2*n&&t<o+3*n?g.zoomFactor=.4:g.zoomFactor=5;else{const p=this.viewer.scene.skyBox;p.alpha=1;const w=this.viewer.scene.skyAtmosphere;w.alpha=1,g.zoomFactor=5}},this.viewer.scene.postRender.addEventListener(this.skyListener)}update(e,t){if(!this.show||e.mode!==m.SceneMode.SCENE3D&&e.mode!==m.SceneMode.MORPHING||!e.passes.render)return;const r=e.context;if(this._sources!==this.sources){this._sources=this.sources;const i=this.sources;if(!m.defined(i.positiveX)||!m.defined(i.negativeX)||!m.defined(i.positiveY)||!m.defined(i.negativeY)||!m.defined(i.positiveZ)||!m.defined(i.negativeZ))throw new m.DeveloperError("this.sources is required and must have positiveX, negativeX, positiveY, negativeY, positiveZ, and negativeZ properties.");if(typeof i.positiveX!=typeof i.negativeX||typeof i.positiveX!=typeof i.positiveY||typeof i.positiveX!=typeof i.negativeY||typeof i.positiveX!=typeof i.positiveZ||typeof i.positiveX!=typeof i.negativeZ)throw new m.DeveloperError("this.sources properties must all be the same type.");typeof i.positiveX=="string"?_.loadCubeMap(r,this._sources).then(n=>{this._cubeMap=this._cubeMap&&this._cubeMap.destroy(),this._cubeMap=n}):(this._cubeMap=this._cubeMap&&this._cubeMap.destroy(),this._cubeMap=new _.CubeMap({context:r,source:i}))}const o=this._command;if(o.modelMatrix=m.Transforms.eastNorthUpToFixedFrame(e.camera._positionWC),!m.defined(o.vertexArray)){o.uniformMap={u_cubeMap:()=>this._cubeMap,u_rotateMatrix:function(){return m.Matrix4.getRotation(o.modelMatrix,new m.Matrix3)}};const i=m.BoxGeometry.createGeometry(m.BoxGeometry.fromDimensions({dimensions:new m.Cartesian3(2,2,2),vertexFormat:m.VertexFormat.POSITION_ONLY})),n=this._attributeLocations=m.GeometryPipeline.createAttributeLocations(i);o.vertexArray=_.VertexArray.fromGeometry({context:r,geometry:i,attributeLocations:n,bufferUsage:_.BufferUsage._DRAW}),o.renderState=_.RenderState.fromCache({blending:m.BlendingState.ALPHA_BLEND})}if(!m.defined(o.shaderProgram)||this._useHdr!==t){const i=new _.ShaderSource({defines:[t?"HDR":""],sources:[dt]});o.shaderProgram=_.ShaderProgram.fromCache({context:r,vertexShaderSource:gt,fragmentShaderSource:i,attributeLocations:this._attributeLocations}),this._useHdr=t}if(m.defined(this._cubeMap))return o}destroy(){const e=this._command;e.vertexArray=e.vertexArray&&e.vertexArray.destroy(),e.shaderProgram=e.shaderProgram&&e.shaderProgram.destroy(),this._cubeMap=this._cubeMap&&this._cubeMap.destroy(),this.viewer.scene.skyBox=this.defaultSkyBox,this.skyListener&&this.viewer.scene.postRender.removeEventListener(this.skyListener)}}const f=Math.PI,I=Math.PI*3e3/180,q=6378245,K=.006693421622965943,ft=(s,e)=>{const t=+s-.0065,r=+e-.006,o=Math.sqrt(t*t+r*r)-2e-5*Math.sin(r*I),i=Math.atan2(r,t)-3e-6*Math.cos(t*I),n=o*Math.cos(i),l=o*Math.sin(i);return[n,l]},vt=(s,e)=>{e=+e,s=+s;const t=Math.sqrt(s*s+e*e)+2e-5*Math.sin(e*I),r=Math.atan2(e,s)+3e-6*Math.cos(s*I),o=t*Math.cos(r)+.0065,i=t*Math.sin(r)+.006;return[o,i]},ce=(s,e)=>{if(e=+e,s=+s,me(s,e))return[s,e];{const t=ue(s,e);return[s+t[0],e+t[1]]}},le=(s,e)=>{if(e=+e,s=+s,me(s,e))return[s,e];{const t=ue(s,e),r=s+t[0],o=e+t[1];return[s*2-r,e*2-o]}},ue=(s,e)=>{let t=wt(s-105,e-35),r=yt(s-105,e-35);const o=e/180*f;let i=Math.sin(o);i=1-K*i*i;const n=Math.sqrt(i);return t=t*180/(q/n*Math.cos(o)*f),r=r*180/(q*(1-K)/(i*n)*f),[t,r]},wt=(s,e)=>{e=+e,s=+s;let t=300+s+2*e+.1*s*s+.1*s*e+.1*Math.sqrt(Math.abs(s));return t+=(20*Math.sin(6*s*f)+20*Math.sin(2*s*f))*2/3,t+=(20*Math.sin(s*f)+40*Math.sin(s/3*f))*2/3,t+=(150*Math.sin(s/12*f)+300*Math.sin(s/30*f))*2/3,t},yt=(s,e)=>{e=+e,s=+s;let t=-100+2*s+3*e+.2*e*e+.1*s*e+.2*Math.sqrt(Math.abs(s));return t+=(20*Math.sin(6*s*f)+20*Math.sin(2*s*f))*2/3,t+=(20*Math.sin(e*f)+40*Math.sin(e/3*f))*2/3,t+=(160*Math.sin(e/12*f)+320*Math.sin(e*f/30))*2/3,t},me=(s,e)=>(e=+e,s=+s,!(s>73.66&&s<135.05&&e>3.86&&e<53.55));window.Cesium.Cartesian3;window.Cesium.Ellipsoid;const he=window.Cesium.Math;window.Cesium.Cartographic;const _t=window.Cesium.WebMercatorProjection;window.Cesium.SceneMode;window.Cesium.SceneTransforms;new _t;const A=s=>he.toDegrees(s),R=s=>he.toRadians(s),Ct=637099681e-2,Q=[1289059486e-2,836237787e-2,5591021,348198983e-2,167804312e-2,0],k=[75,60,45,30,15,0],xt=[[1410526172116255e-23,898305509648872e-20,-1.9939833816331,200.9824383106796,-187.2403703815547,91.6087516669843,-23.38765649603339,2.57121317296198,-.03801003308653,173379812e-1],[-7435856389565537e-24,8983055097726239e-21,-.78625201886289,96.32687599759846,-1.85204757529826,-59.36935905485877,47.40033549296737,-16.50741931063887,2.28786674699375,1026014486e-2],[-3030883460898826e-23,898305509983578e-20,.30071316287616,59.74293618442277,7.357984074871,-25.38371002664745,13.45380521110908,-3.29883767235584,.32710905363475,685681737e-2],[-1981981304930552e-23,8983055099779535e-21,.03278182852591,40.31678527705744,.65659298677277,-4.44255534477492,.85341911805263,.12923347998204,-.04625736007561,448277706e-2],[309191371068437e-23,8983055096812155e-21,6995724062e-14,23.10934304144901,-.00023663490511,-.6321817810242,-.00663494467273,.03430082397953,-.00466043876332,25551644e-1],[2890871144776878e-24,8983055095805407e-21,-3068298e-14,7.47137025468032,-353937994e-14,-.02145144861037,-1234426596e-14,.00010322952773,-323890364e-14,826088.5]],$=[[-.0015702102444,111320.7020616939,0x60e374c3105a3,-0x24bb4115e2e164,0x5cc55543bb0ae8,-0x7ce070193f3784,0x5e7ca61ddf8150,-0x261a578d8b24d0,0x665d60f3742ca,82.5],[.0008277824516172526,111320.7020463578,64779557466716e-5,-4082003173641316e-6,1077490566351142e-5,-1517187553151559e-5,1205306533862167e-5,-5124939663577472e-6,9133119359512032e-7,67.5],[.00337398766765,111320.7020202162,4481351045890365e-9,-2339375119931662e-8,7968221547186455e-8,-1159649932797253e-7,9723671115602145e-8,-4366194633752821e-8,8477230501135234e-9,52.5],[.00220636496208,111320.7020209128,51751.86112841131,3796837749470245e-9,992013.7397791013,-122195221711287e-8,1340652697009075e-9,-620943.6990984312,144416.9293806241,37.5],[-.0003441963504368392,111320.7020576856,278.2353980772752,2485758690035394e-9,6070.750963243378,54821.18345352118,9540.606633304236,-2710.55326746645,1405.483844121726,22.5],[-.0003218135878613132,111320.7020701615,.00369383431289,823725.6402795718,.46104986909093,2351.343141331292,1.58060784298199,8.77738589078284,.37238884252424,7.45]];class St{constructor(){a(this,"isWgs84",!1)}getDistanceByMC(e,t){if(!e||!t)return 0;const r=this.convertMC2LL(e);if(!r)return 0;const o=this.toRadians(r.longitude),i=this.toRadians(r.latitude),n=this.convertMC2LL(t);if(!n)return 0;const l=this.toRadians(n.longitude),g=this.toRadians(n.latitude);return this.getDistance(o,l,i,g)}getDistanceByLL(e,t){if(!e||!t)return 0;e.longitude=this.getLoop(e.longitude,-180,180),e.latitude=this.getRange(e.latitude,-74,74),t.longitude=this.getLoop(t.longitude,-180,180),t.latitude=this.getRange(t.latitude,-74,74);const r=this.toRadians(e.longitude),o=this.toRadians(e.latitude),i=this.toRadians(t.longitude),n=this.toRadians(t.latitude);return this.getDistance(r,i,o,n)}convertMC2LL(e){if(!e)return{longitude:0,latitude:0};let t={longitude:0,latitude:0};if(this.isWgs84){t.longitude=e.longitude/2003750834e-2*180;const i=e.latitude/2003750834e-2*180;return t.latitude=180/Math.PI*(2*Math.atan(Math.exp(i*Math.PI/180))-Math.PI/2),{longitude:Number.parseFloat(t.longitude.toFixed(8)),latitude:Number.parseFloat(t.latitude.toFixed(8))}}const r={longitude:Math.abs(e.longitude),latitude:Math.abs(e.latitude)};let o=[];for(let i=0;i<Q.length;i++)if(r.latitude>=Q[i]){o=xt[i];break}return t=this.convertor(e,o),{longitude:Number.parseFloat(t.longitude.toFixed(8)),latitude:Number.parseFloat(t.latitude.toFixed(8))}}convertLL2MC(e){if(!e)return{longitude:0,latitude:0};if(e.longitude>180||e.longitude<-180||e.latitude>90||e.latitude<-90)return e;if(this.isWgs84){const i={longitude:0,latitude:0},n=6378137;i.longitude=e.longitude*Math.PI/180*n;const l=e.latitude*Math.PI/180;return i.latitude=n/2*Math.log((1+Math.sin(l))/(1-Math.sin(l))),{longitude:parseFloat(i.longitude.toFixed(2)),latitude:parseFloat(i.latitude.toFixed(2))}}e.longitude=this.getLoop(e.longitude,-180,180),e.latitude=this.getRange(e.latitude,-74,74);const t={longitude:e.longitude,latitude:e.latitude};let r=[];for(let i=0;i<k.length;i++)if(t.latitude>=k[i]){r=$[i];break}if(!r.length){for(let i=0;i<k.length;i++)if(t.latitude<=-k[i]){r=$[i];break}}const o=this.convertor(e,r);return{longitude:parseFloat(o.longitude.toFixed(2)),latitude:parseFloat(o.latitude.toFixed(2))}}convertor(e,t){if(!e||!t)return{longitude:0,latitude:0};let r=t[0]+t[1]*Math.abs(e.longitude);const o=Math.abs(e.latitude)/t[9];let i=t[2]+t[3]*o+t[4]*o*o+t[5]*o*o*o+t[6]*o*o*o*o+t[7]*o*o*o*o*o+t[8]*o*o*o*o*o*o;return r*=e.longitude<0?-1:1,i*=e.latitude<0?-1:1,{longitude:r,latitude:i}}getDistance(e,t,r,o){return Ct*Math.acos(Math.sin(r)*Math.sin(o)+Math.cos(r)*Math.cos(o)*Math.cos(t-e))}toRadians(e){return Math.PI*e/180}toDegrees(e){return 180*e/Math.PI}getRange(e,t,r){return t!=null&&(e=Math.max(e,t)),r!=null&&(e=Math.min(e,r)),e}getLoop(e,t,r){for(;e>r;)e-=r-t;for(;e<t;)e+=r-t;return e}lngLatToMercator(e){return this.convertLL2MC(e)}lngLatToPoint(e){const t=this.convertLL2MC(e);return{x:t.longitude,y:t.latitude}}mercatorToLngLat(e){return this.convertMC2LL(e)}pointToLngLat(e){const t={longitude:e.x,latitude:e.y};return this.convertMC2LL(t)}pointToPixel(e,t,r,o){if(!e)return{x:0,y:0};e=this.lngLatToMercator(e);const i=this.getZoomUnits(t),n=Math.round((e.longitude-r.longitude)/i+o.width/2),l=Math.round((r.latitude-e.latitude)/i+o.height/2);return{x:n,y:l}}pixelToPoint(e,t,r,o){if(!e)return{longitude:0,latitude:0};const i=this.getZoomUnits(t),n=r.longitude+i*(e.x-o.width/2),l=r.latitude-i*(e.y-o.height/2),g={longitude:n,latitude:l};return this.mercatorToLngLat(g)}getZoomUnits(e){return Math.pow(2,18-e)}}const ee=window.Cesium.Cartesian2,Lt=window.Cesium.Cartographic,te=window.Cesium.Rectangle,V=window.Cesium.defined,Mt=window.Cesium.WebMercatorTilingScheme;class bt extends Mt{constructor(e){super(e);const t=new St;this._projection.project=r=>{const o=ce(A(r.longitude),A(r.latitude)),i=vt(o[0],o[1]),n=[];n[0]=Math.min(i[0],180),n[0]=Math.max(n[0],-180),n[1]=Math.min(i[1],74.000022),n[1]=Math.max(n[1],-71.988531);const l=t.lngLatToPoint({longitude:n[0],latitude:n[1]});return new ee(l.x,l.y)},this._projection.unproject=r=>{const o=t.mercatorToLngLat({longitude:r.x,latitude:r.y});let i=ft(o.longitude,o.latitude);return i=le(i[0],i[1]),new Lt(R(i[0]),R(i[1]))},this.resolutions=(e==null?void 0:e.resolutions)||[]}tileXYToNativeRectangle(e,t,r,o){const i=this.resolutions[r],n=e*i,l=(e+1)*i,g=((t=-t)+1)*i,p=t*i;return V(o)?(o.west=n,o.south=p,o.east=l,o.north=g,o):new te(n,p,l,g)}positionToTileXY(e,t,r){const o=this._rectangle;if(!te.contains(o,e))return;const n=this._projection.project(e);if(!V(n))return;const l=this.resolutions[t],g=Math.floor(n.x/l),p=-Math.floor(n.y/l);return V(r)?(r.x=g,r.y=p,r):new ee(g,p)}}const E=window.Cesium.Cartesian2,At=window.Cesium.WebMercatorTilingScheme,S=window.Cesium.DeveloperError,Rt=window.Cesium.ImageryProvider,Pt="http://shangetu{s}.map.bdimg.com/it/u=x={x};y={y};z={z};v=009;type=sate&fm=46",Ut="http://its.map.baidu.com:8002/traffic/TrafficTileService?time={time}&label={labelStyle}&v=016&level={z}&x={x}&y={y}&scaler=2";class Tt{constructor(e){a(this,"_url");a(this,"_labelStyle");a(this,"_tileWidth");a(this,"_tileHeight");a(this,"_maximumLevel");a(this,"_crs");a(this,"_tilingScheme");a(this,"_rectangle");a(this,"_credit");a(this,"_token");a(this,"_style");a(this,"_scaler");if(this._scaler=e.scaler??1,this._url=this.getUrl(e.style),this._labelStyle=e.labelStyle||"web2D",this._tileWidth=256,this._tileHeight=256,this._maximumLevel=18,this._crs=e.crs||"BD09",e.crs==="WGS84"){const t=[];for(let r=0;r<19;r++)t[r]=256*Math.pow(2,18-r);this._tilingScheme=new bt({resolutions:t,rectangleSouthwestInMeters:new E(-2003772637e-2,-1247410417e-2),rectangleNortheastInMeters:new E(2003772637e-2,1247410417e-2)})}else this._tilingScheme=new At({rectangleSouthwestInMeters:new E(-33554054,-33746824),rectangleNortheastInMeters:new E(33554054,33746824)});this._rectangle=this._tilingScheme.rectangle,this._token=void 0,this._style=e.style||"normal"}get url(){return this._url}get token(){return this._token}get tileWidth(){if(!this.ready)throw new S("tileWidth must not be called before the imagery provider is ready.");return this._tileWidth}get tileHeight(){if(!this.ready)throw new S("tileHeight must not be called before the imagery provider is ready.");return this._tileHeight}get maximumLevel(){if(!this.ready)throw new S("maximumLevel must not be called before the imagery provider is ready.");return this._maximumLevel}get minimumLevel(){if(!this.ready)throw new S("minimumLevel must not be called before the imagery provider is ready.");return 0}get tilingScheme(){if(!this.ready)throw new S("tilingScheme must not be called before the imagery provider is ready.");return this._tilingScheme}get rectangle(){if(!this.ready)throw new S("rectangle must not be called before the imagery provider is ready.");return this._rectangle}get ready(){return!!this._url}get credit(){return this._credit}get hasAlphaChannel(){return!0}getUrl(e){return e==="img"?Pt:e==="vec"?`http://online{s}.map.bdimg.com/onlinelabel/?qt=tile&x={x}&y={y}&z={z}&styles=pl&scaler=${this._scaler}&p=1`:e==="traffic"?Ut:"http://api{s}.map.bdimg.com/customimage/tile?&x={x}&y={y}&z={z}&scale=1&customid="+this._style}requestImage(e,t,r){if(!this.ready)throw new S("requestImage must not be called before the imagery provider is ready.");const o=this._tilingScheme.getNumberOfXTilesAtLevel(r),i=this._tilingScheme.getNumberOfYTilesAtLevel(r);let n=this._url.replace("{z}",r+"").replace("{s}",String(1)).replace("{style}",this._style).replace("{labelStyle}",this._labelStyle).replace("{time}",String(new Date().getTime()));return this._crs==="WGS84"?n=n.replace("{x}",String(e)).replace("{y}",String(-t)):n=n.replace("{x}",String(e-o/2)).replace("{y}",String(i/2-t-1)),Rt.loadImage(this,n)}}const Dt=window.Cesium.Cartesian2,ie=window.Cesium.Cartographic,Bt=window.Cesium.WebMercatorProjection,kt=window.Cesium.WebMercatorTilingScheme;class Et extends kt{constructor(e){super(e);const t=new Bt;this._projection.project=(r,o)=>{const i=ce(A(r.longitude),A(r.latitude));return o=t.project(new ie(R(i[0]),R(i[1]))),new Dt(o.x,o.y)},this._projection.unproject=function(r,o){const i=t.unproject(r),n=le(A(i.longitude),A(i.latitude));return o=new ie(R(n[0]),R(n[1])),o}}}const zt=window.Cesium.UrlTemplateImageryProvider,It="https://webst{s}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}",Ft="http://webrd{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}",Nt="https://webst{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}";class Ot extends zt{constructor(e){e.url=(e==null?void 0:e.style)==="img"?It:(e==null?void 0:e.style)==="cva"?Nt:Ft,e.subdomains=e.subdomains||["01","02","03","04"],e.crs==="WGS84"&&(e.tilingScheme=new Et),super(e)}}const Wt=window.Cesium.UrlTemplateImageryProvider,oe={img:"//p{s}.map.gtimg.com/sateTiles/{z}/{sx}/{sy}/{x}_{reverseY}.jpg?version=400",elec:"//rt{s}.map.gtimg.com/tile?z={z}&x={x}&y={reverseY}&styleid={style}&scene=0&version=347"};class jt extends Wt{constructor(e){const t=e.url||[e.protocol||"",oe[e.style]||oe.elec].join("");e.url=t.replace("{style}",e.style||1),e.subdomains=e.subdomains||["1","2","3"],e.style==="img"&&(e.customTags={sx:(r,o,i,n)=>o>>4,sy:(r,o,i,n)=>(1<<n)-i>>4}),super(e)}}const z=window.Cesium;class Gt{constructor(e){a(this,"options");a(this,"scales84");a(this,"scalesweb");a(this,"delegate");this.options=Object.assign({},{minimumLevel:0,maximumLevel:18,epsgcode:3857,token:""},e),this.scales84=[338032714321e-20,676065428641e-20,1352130857282e-20,2704261714564e-20,5408523429128e-20,10817046858257e-20,21634093716514e-20,43268187433028e-20,86536374866056e-20,173072749732112e-20,346145499464224e-20,692290998928448e-20,13845819978568952e-21,27691639957137904e-21,5538327991427581e-20,.00011076655982855162,.00022153311965710323,.00044306623931420646,.0008861324786284129,.0017722649572568258,.0035445299145136517,.007089059829027303],this.scalesweb=[16901635716e-19,338032714321e-20,676065428641e-20,1352130857282e-20,2704261714564e-20,5408523429128e-20,10817046858257e-20,21634093716514e-20,43268187433028e-20,86536374866056e-20,173072749732112e-20,346145499464224e-20,692290998928448e-20,13845819978568952e-21,27691639957137904e-21,5538327991427581e-20,.00011076655982855162,.00022153311965710323,.00044306623931420646,.0008861324786284129,.0017722649572568258,.0035445299145136517,.007089059829027303],this.delegate=this.createSuperMapLayer(this.options)}createSuperMapLayer(e){const t=z.Rectangle.fromDegrees(-180,-90,180,90),r=e.epsgcode;let o,i=0,n=22,l=0,g=0;r===4326&&(o=new z.GeographicTilingScheme({numberOfLevelZeroTilesX:2,numberOfLevelZeroTilesY:1}),l=-180,g=90,e.minimumLevel!==void 0?i=e.minimumLevel:i=0,e.maximumLevel!==void 0?n=e.maximumLevel:n=22),r===3857&&(o=new z.WebMercatorTilingScheme,l=-2003750834e-2,g=2003750834e-2,e.minimumLevel!==void 0?(console.log("not undefined"),i=e.minimumLevel):i=0,e.maximumLevel!==void 0?n=e.maximumLevel:n=22);const p=`{"x":${l},"y":${g}}`,w=`${this.options.url}/tileImage.png?transparent=true&cacheEnabled=true&width=256&height=256&x={x}&y={y}&scale={scale}&redirect=false&overlapDisplayed=false&origin={origin}`;return new z.UrlTemplateImageryProvider({url:w,rectangle:t,minimumLevel:i||0,maximumLevel:n||22,tilingScheme:o,customTags:{scale:(F,N,d,c)=>{if(r===4326)return this.scales84[c];if(r===3857)return this.scalesweb[c]},origin:()=>p}})}}const Vt={Navigation:at},Ht={MouseTip:ht},Xt=new URL(""+new URL("../img/world_b.CKToTiVD.jpg",import.meta.url).href,import.meta.url).href,Zt=new URL(""+new URL("../img/world_img.BGGjUUzF.jpg",import.meta.url).href,import.meta.url).href,Yt=new URL(""+new URL("../img/backGroundImg.CHcdoOpt.jpg",import.meta.url).href,import.meta.url).href,Jt={positiveX:new URL(""+new URL("../img/Right.DvICu_nL.jpg",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.Beb91ZrI.jpg",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.CNsTSgXm.jpg",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.Cc3mBCf3.jpg",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.Bw1YxhIs.jpg",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.BvGcIg6o.jpg",import.meta.url).href,import.meta.url).href},qt={positiveX:new URL(""+new URL("../img/Right.DdlANBEa.jpg",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.B8rfaA0r.jpg",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.DPEAmiXi.jpg",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.DJrVM9dN.jpg",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.CMCoYR6m.jpg",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.lnNfcNjB.jpg",import.meta.url).href,import.meta.url).href},Kt={positiveX:new URL(""+new URL("../img/Right.D5T4YmHC.png",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.CvRmAvgL.png",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.2o9Lxxyg.png",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.C49sX_sW.png",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.B-I1Cg_a.png",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.CRKe6wcu.png",import.meta.url).href,import.meta.url).href},Qt={positiveX:new URL(""+new URL("../img/Right.DfXBh-Je.jpg",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.DAu_0SLw.jpg",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.Cu5ZW8wg.jpg",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.DzIrvXSv.jpg",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.CPesry4o.jpg",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.BHPfJ1nb.jpg",import.meta.url).href,import.meta.url).href},de={dat:De,Lightning:Ye,Rain:Je,Fog:$e,Snow:tt,GroundSkyBox:pt,BaiduImageryProvider:Tt,AmapImageryProvider:Ot,TencentImageryProvider:jt,SuperMapImagryProvider:Gt,Widgets:Vt,MapTools:Ht,useViewerHook:ae,BaseMapWorld_Blue:Xt,BaseMapWorld_Image:Zt,SceneBackGroundImg:Yt,GroundSkyBoxBlueSky:Jt,GroundSkyBoxSun:qt,GroundSkyBoxSunsetGlow:Kt,GroundSkyBoxNight:Qt};for(const[s,e]of Object.entries(de))Reflect.defineProperty(window,s,{value:e});const Z=document.createElement("link");Z.rel="stylesheet";Z.href="//at.alicdn.com/t/c/font_4702543_kgiwod8u1v.css";document.head.appendChild(Z);const U=Le(ke);ze(U);for(const[s,e]of Object.entries(Te))U.component(s,e);for(const[s,e]of Object.entries(de.Widgets))U.component(s,e);U.component("IconSvg",Xe);U.use(ve,{locale:we});U.use(Oe).mount("#app");export{ne as _};
