const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./index.26f61cf4.js","./monaco-editor.D3ig2Cuf.js","../css/monaco-editor.BzWl1eyH.css","./vue.ClgfzGxZ.js","./@vue.Lfky3Lsd.js","./@vueuse.BGoRStkq.js","./vue3-sfc-loader.CoUr1SK8.js","./@turf.BhhZGEnx.js","./point-in-polygon-hao.CVtqB2KT.js","./sweepline-intersections.D78iGcFZ.js","./geojson-equality-ts.385IDfwq.js","./fast-deep-equal.BZWWD7KU.js","./d3-geo.B8ycIn1u.js","./d3-array.0UpHvbR7.js","./concaveman.D4rCrqp7.js","./tinyqueue.BpsZqhqS.js","./point-in-polygon.BrHNa-um.js","./robust-predicates.DbhKlCUI.js","./skmeans.Df_G8q9F.js","./topojson-client.C_Q_XF1Z.js","./topojson-server.BJ5ICLc2.js","./polygon-clipping.C7RG_Bzj.js","./splaytree.t-pFliWO.js","./marchingsquares.DR8wX6S2.js","./d3-voronoi.DD4zjRyK.js","./dat.gui.kzZ7KUwl.js","./vue-router.bYO7SHUI.js","./element-plus.BHdALmn5.js","./lodash-es.CiJSjksT.js","./@element-plus.DY0ir03P.js","./@popperjs.D9SI2xQl.js","./@ctrl.r5W6hzzQ.js","./dayjs.Dldw1-ZD.js","./async-validator.DKvM95Vc.js","./memoize-one.BdPwpGay.js","./normalize-wheel-es.B6fDCfyv.js","./@floating-ui.8uccrNCM.js","../css/element-plus.B2tId5af.css","./pinia.BCCKnU4o.js","../css/index.BrWGY-An.css","../css/cesium.BHwS5cQ6.css","./index.246e82ba.js","../css/index.DBIOOUz6.css"])))=>i.map(i=>d[i]);
var v=Object.defineProperty;var _=(t,e,i)=>e in t?v(t,e,{enumerable:!0,configurable:!0,writable:!0,value:i}):t[e]=i;var r=(t,e,i)=>_(t,typeof e!="symbol"?e+"":e,i);import"./vue.ClgfzGxZ.js";/* empty css               */import{E as w,i as x,z as y}from"./element-plus.BHdALmn5.js";import{d,M as C,u as S,ai as P,o as f,O as b,U as k,c as m,a as B,I as D,au as z}from"./@vue.Lfky3Lsd.js";import{c as L}from"./pinia.BCCKnU4o.js";import{_ as h}from"./monaco-editor.D3ig2Cuf.js";import{c as R,a as T}from"./vue-router.bYO7SHUI.js";import{Q as E}from"./@element-plus.DY0ir03P.js";import{d as I}from"./dat.gui.kzZ7KUwl.js";import"./lodash-es.CiJSjksT.js";import"./@vueuse.BGoRStkq.js";import"./@popperjs.D9SI2xQl.js";import"./@ctrl.r5W6hzzQ.js";import"./dayjs.Dldw1-ZD.js";import"./@turf.BhhZGEnx.js";import"./point-in-polygon-hao.CVtqB2KT.js";import"./sweepline-intersections.D78iGcFZ.js";import"./geojson-equality-ts.385IDfwq.js";import"./fast-deep-equal.BZWWD7KU.js";import"./d3-geo.B8ycIn1u.js";import"./d3-array.0UpHvbR7.js";import"./concaveman.D4rCrqp7.js";import"./tinyqueue.BpsZqhqS.js";import"./point-in-polygon.BrHNa-um.js";import"./robust-predicates.DbhKlCUI.js";import"./skmeans.Df_G8q9F.js";import"./topojson-client.C_Q_XF1Z.js";import"./topojson-server.BJ5ICLc2.js";import"./polygon-clipping.C7RG_Bzj.js";import"./splaytree.t-pFliWO.js";import"./marchingsquares.DR8wX6S2.js";import"./d3-voronoi.DD4zjRyK.js";import"./async-validator.DKvM95Vc.js";import"./memoize-one.BdPwpGay.js";import"./normalize-wheel-es.B6fDCfyv.js";import"./@floating-ui.8uccrNCM.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))n(o);new MutationObserver(o=>{for(const s of o)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function i(o){const s={};return o.integrity&&(s.integrity=o.integrity),o.referrerPolicy&&(s.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?s.credentials="include":o.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function n(o){if(o.ep)return;o.ep=!0;const s=i(o);fetch(o.href,s)}})();const U=d({__name:"App",setup(t){const e="production",n="https://www.unpkg.com/cesium@1.120.0/Build/Cesium/";return window.CESIUM_BASE_URL=n,console.log(`模式: ${e}, CESIUM_BASE_URL: ${n}`),(o,s)=>{const a=P("router-view");return f(),C(S(w),{size:"default"},{default:b(()=>[k(a)]),_:1})}}}),g=(t,e)=>{const i=t.__vccOpts||t;for(const[n,o]of e)i[n]=o;return i},A=g(U,[["__scopeId","data-v-6ec92aea"]]),O=L();function V(t){t.use(O)}const F=()=>h(()=>import("./index.26f61cf4.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40]),import.meta.url),M=()=>h(()=>import("./index.246e82ba.js"),__vite__mapDeps([41,3,4,38,27,28,5,29,30,31,32,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,33,34,35,36,37,1,2,26,25,42,40]),import.meta.url),N=[{path:"/",redirect:"/example"},{path:"/example",component:M,name:"example"},{path:"/example/preview",component:F,name:"preview"}],$=R({history:T(),routes:N,scrollBehavior:()=>({left:0,top:0})}),j=d({name:"IconSvg",props:{value:{type:String,required:!0}}}),G={key:0,class:"com-icon"},H={class:"com-icon-svg","aria-hidden":"true"},W=["xlink:href"];function q(t,e,i,n,o,s){return t.value.indexOf("#")===0?(f(),m("i",G,[(f(),m("svg",H,[B("use",{"xlink:href":t.value},null,8,W)]))])):(f(),m("i",{key:1,class:D(t.value)},null,2))}const K=g(j,[["render",q],["__scopeId","data-v-f8504d79"]]),l=window.Cesium,Q=`
  uniform sampler2D colorTexture;
  uniform bool showLightning;
  in vec2 v_textureCoordinates;
  

  float rand(float x)
  {
    return fract(sin(x)*75154.32912);
  }

  // 使用Perlin噪声生成3D伪随机噪声
  float rand3d(vec3 x)
  {
    return fract(375.10297*sin(dot(x,vec3(103.0139,227.0595,31.05914))));
  }
  // 生成1D Perlin噪声
  float noise(float x)
  {
    float i=floor(x);
    float a=rand(i),b=rand(i+1.);
    float f=x-i;
    return mix(a,b,f);
  }

  // 结合多个1D Perlin噪声的八度
  float perlin(float x)
  {
    float r=0.,s=1.,w=1.;
    for(int i=0;i<6;i++){
      s*=2.;
      w*=.5;
      r+=w*noise(s*x);
    }
    return r;
  }
  // 生成3D Perlin噪声
  float noise3d(vec3 x)
  {
    vec3 i=floor(x);
    float i000=rand3d(i+vec3(0.,0.,0.)),i001=rand3d(i+vec3(0.,0.,1.));
    float i010=rand3d(i+vec3(0.,1.,0.)),i011=rand3d(i+vec3(0.,1.,1.));
    float i100=rand3d(i+vec3(1.,0.,0.)),i101=rand3d(i+vec3(1.,0.,1.));
    float i110=rand3d(i+vec3(1.,1.,0.)),i111=rand3d(i+vec3(1.,1.,1.));
    vec3 f=x-i;
    return mix(mix(mix(i000,i001,f.z),mix(i010,i011,f.z),f.y),
    mix(mix(i100,i101,f.z),mix(i110,i111,f.z),f.y),f.x);
  }

  // 结合多个3D Perlin噪声的八度
  float perlin3d(vec3 x)
  {
    float r=0.;
    float w=1.,s=1.;
    for(int i=0;i<5;i++){
      w*=.5;
      s*=2.;
      r+=w*noise3d(s*x);
    }
    return r;
  }

  // 基于Perlin噪声生成闪电形状
  float f(float y)
  {
    float w=.4;// 走向宽度
    return w*(perlin(2.*y)-.5);
  }

  // 绘制闪电，可选择增加厚度
  float plot(vec2 p,float d,bool thicker)
  {
    if(thicker)d+=5.*abs(f(p.y+.001)-f(p.y));
    return smoothstep(d,0.,abs(f(p.y)-p.x));
  }

  // 基于3D Perlin噪声生成云效果
  float cloud(vec2 uv,float speed,float scale,float cover)
  {
    float iTime=czm_frameNumber*.008;
    float c=perlin3d(vec3(uv*scale,iTime*speed*2.));
    return max(0.,c-(1.-cover));
  }

  vec3 render(vec2 uv)
  {
    float iTime=czm_frameNumber*.008;
    float x=iTime+.1;
    float m=.25;// 闪电形状持续时间
    float i=floor(x/m);
    float f=x/m-i;
    float k=.4;// 闪电间隔/频率
    float n=noise(i);
    float t=ceil(n-k);
    float d=max(0.,n-k)/(1.-k);
    float o=ceil(t-f-(1.-d));
    float gt=.1;
    float go=ceil(t-f-(1.-gt));

    float lightning=0.;
    float light=0.;
    float glare=0.;
    if(o==1.){
      vec2 uv2=uv;
      uv2.y+=i*2.;
      float p=(noise(i+10.)-.5)*2.;
      uv2.x-=p;

      float strike=plot(uv2,.01,true);
      float glow=plot(uv2,.04,false);
      float glow2=plot(uv2,1.5,false);

      lightning=strike*.4+glow*.15;

      float h=noise(i+5.);
      lightning*=smoothstep(h,h+.05,uv.y+perlin(1.2*uv.x+4.*h)*.03);
      lightning+=glow2*.3;
      light=smoothstep(5.,0.,abs(uv.x-p));
      glare=go*light;
    }

    vec3 clouds=
    vec3(.5,.7,1.)*mix(.6,.9,cloud(uv,.2,.1,1.))+
    vec3(.7,.8,1.)*.6*cloud(uv*vec2(.5,1.),.06,.8,.8)+
    vec3(.9,.9,1.)*.3*cloud(uv*vec2(.1,1.),.08,5.5,.6)+
    vec3(1.,1.,1.)*.4*cloud(uv*vec2(.1,1.),.07,10.,.5);

    vec3 background=vec3(.8);//背景颜色
    background*=(.2+light*.5);
    if(showLightning == true){
      return vec3(background+lightning+glare);
    }else {
      return vec3(background+glare);
    }
    
  }

  void main()
  {
    vec2 iResolution=czm_viewport.zw;
    vec2 uv=(gl_FragCoord.xy*2.-iResolution.xy)/iResolution.y;

    out_FragColor=vec4(render(uv),1.);

    vec4 sceneColor=texture(colorTexture,v_textureCoordinates);
    out_FragColor=mix(out_FragColor,sceneColor,.5);
  }
`;class J{constructor(e){r(this,"_viewer");r(this,"showLightning",!1);r(this,"_lighting");this._viewer=e}init(){this._lighting=new l.PostProcessStage({name:"weather_lighting",fragmentShader:Q,uniforms:{fogByDistance:new l.Cartesian4(10,0,1e3,.8),fogColor:l.Color.WHITE,showLightning:()=>this.showLightning}}),this._viewer.scene.postProcessStages.add(this._lighting),this._viewer.scene.postRender.addEventListener(()=>{const e=l.Math.toDegrees(this._viewer.camera.pitch);this.showLightning=e>-15})}destroy(){var e;this.clear(),(e=this._lighting)==null||e.destroy()}clear(){!this._viewer||!this._lighting||this._viewer.scene.postProcessStages.remove(this._lighting)}show(e){e?this.init():this.clear()}}const u=window.Cesium;class X{constructor(e,i){r(this,"viewer");r(this,"angle");r(this,"size");r(this,"speed");r(this,"rainStage");if(!e)throw new Error("no viewer object!");i=i||{},this.angle=u.defaultValue(i.angle,-.6),this.size=u.defaultValue(i.size,.1),this.speed=u.defaultValue(i.speed,1e3),this.viewer=e,this.init()}show(e){this.rainStage.enabled=e}init(){this.rainStage=new u.PostProcessStage({name:"czml_rain",fragmentShader:this.rain(),uniforms:{angle:()=>this.angle,size:()=>this.size,speed:()=>this.speed}}),this.viewer.scene.postProcessStages.add(this.rainStage)}destroy(){!this.viewer||!this.rainStage||this.viewer.scene.postProcessStages.remove(this.rainStage)}rain(){return`uniform sampler2D colorTexture;
              varying vec2 v_textureCoordinates;
              uniform float angle;
              uniform float size;
              uniform float speed;
              float hash(float x){
                  return fract(sin(x*133.3)*13.13);
          }
          void main(void){
              float time = czm_frameNumber / speed;
              vec2 resolution = czm_viewport.zw;
              vec2 uv=(gl_FragCoord.xy*2.-resolution.xy)/min(resolution.x,resolution.y);
              vec3 c=vec3(.6,.7,.8);
              float a=angle;
              float si=sin(a),co=cos(a);
              uv*=mat2(co,-si,si,co);
              uv*=length(uv+vec2(0,4.9))*size + 1.;
              float v=1.-sin(hash(floor(uv.x*100.))*2.);
              float b=clamp(abs(sin(20.*time*v+uv.y*(5./(2.+v))))-.95,0.,1.)*20.;
              c*=v*b; 
              gl_FragColor = mix(texture2D(colorTexture, v_textureCoordinates), vec4(c,1), 0.5);  
          }
           `}}const Y=window.Cesium.Cartesian4,Z=window.Cesium.Color,ee=window.Cesium.PostProcessStage;class te{constructor(e){r(this,"viewer");r(this,"collection");r(this,"postProcessState");r(this,"_fogByDistance",{near:500,nearValue:0,far:2e3,farValue:1});r(this,"_color",new Z(1,1,1,1));r(this,"_visibility",1);this.viewer=e,this.collection=e.scene.postProcessStages}set fogByDistance(e){this._fogByDistance=e}get fogByDistance(){return this._fogByDistance}set color(e){this._color=e}get color(){return this._color}get visibility(){return this._visibility}set visibility(e){this._visibility=e}_createPostProcessStage(){var e,i,n,o;this.postProcessState=new ee({name:"czm_fog",fragmentShader:this._getFs(),uniforms:{fogColor:()=>this._color,visibility:()=>this._visibility,fogByDistance:new Y(((e=this._fogByDistance)==null?void 0:e.near)||10,((i=this._fogByDistance)==null?void 0:i.nearValue)||0,((n=this._fogByDistance)==null?void 0:n.far)||200,((o=this._fogByDistance)==null?void 0:o.farValue)||1)}}),this.collection.add(this.postProcessState)}_getFs(){return`uniform sampler2D colorTexture;
         uniform sampler2D depthTexture;
         uniform float visibility;
         uniform vec4 fogColor;
         varying vec2 v_textureCoordinates; 
         void main(void) 
         {
            vec4 origcolor = texture2D(colorTexture, v_textureCoordinates); 
            float depth = czm_readDepth(depthTexture, v_textureCoordinates); 
            vec4 depthcolor = texture2D(depthTexture, v_textureCoordinates); 
            float f = visibility * (depthcolor.r - 0.2) / 0.2; 
            if (f < 0.0) f = 0.0; 
            else if (f > 1.0) f = 1.0; 
            gl_FragColor = mix(origcolor, fogColor, f); 
         }`}open(){const e=this.viewer.scene;this.postProcessState||(this._createPostProcessStage(),e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.7,e.fog.density=5e-4,e.fog.minimumBrightness=.03)}close(){const e=this.viewer.scene;this.postProcessState&&(this.collection.remove(this.postProcessState),this.postProcessState=void 0,e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.4,e.fog.density=2e-4,e.fog.minimumBrightness=.03)}}const oe=new URL(""+new URL("../img/world_b.CKToTiVD.jpg",import.meta.url).href,import.meta.url).href,ie=new URL(""+new URL("../img/world_img.BGGjUUzF.jpg",import.meta.url).href,import.meta.url).href,re=new URL(""+new URL("../img/backGroundImg.CHcdoOpt.jpg",import.meta.url).href,import.meta.url).href,se={dat:I,Lightning:J,Rain:X,Fog:te,BaseMapWorld_Blue:oe,BaseMapWorld_Image:ie,SceneBackGroundImg:re};for(const[t,e]of Object.entries(se)){debugger;Reflect.defineProperty(window,t,{value:e})}const p=document.createElement("link");p.rel="stylesheet";p.href="//at.alicdn.com/t/c/font_4702543_kgiwod8u1v.css";document.head.appendChild(p);const c=z(A);V(c);for(const[t,e]of Object.entries(E))c.component(t,e);c.component("IconSvg",K);c.use(x,{locale:y});c.use($).mount("#app");export{g as _};
