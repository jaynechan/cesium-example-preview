const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./index.37019a6f.js","./monaco-editor.D3ig2Cuf.js","../css/monaco-editor.BzWl1eyH.css","./vue.ClgfzGxZ.js","./@vue.Lfky3Lsd.js","./@vueuse.BGoRStkq.js","./vue3-sfc-loader.CoUr1SK8.js","./@turf.BhhZGEnx.js","./point-in-polygon-hao.CVtqB2KT.js","./sweepline-intersections.D78iGcFZ.js","./geojson-equality-ts.385IDfwq.js","./fast-deep-equal.BZWWD7KU.js","./d3-geo.B8ycIn1u.js","./d3-array.0UpHvbR7.js","./concaveman.D4rCrqp7.js","./tinyqueue.BpsZqhqS.js","./point-in-polygon.BrHNa-um.js","./robust-predicates.DbhKlCUI.js","./skmeans.Df_G8q9F.js","./topojson-client.C_Q_XF1Z.js","./topojson-server.BJ5ICLc2.js","./polygon-clipping.C7RG_Bzj.js","./splaytree.t-pFliWO.js","./marchingsquares.DR8wX6S2.js","./d3-voronoi.DD4zjRyK.js","./dat.gui.kzZ7KUwl.js","./vue-router.bYO7SHUI.js","./element-plus.BHdALmn5.js","./lodash-es.CiJSjksT.js","./@element-plus.DY0ir03P.js","./@popperjs.D9SI2xQl.js","./@ctrl.r5W6hzzQ.js","./dayjs.Dldw1-ZD.js","./async-validator.DKvM95Vc.js","./memoize-one.BdPwpGay.js","./normalize-wheel-es.B6fDCfyv.js","./@floating-ui.8uccrNCM.js","../css/element-plus.B2tId5af.css","./pinia.BCCKnU4o.js","../css/index.CbLe1Sa8.css","../css/cesium.BHwS5cQ6.css","./index.13853179.js","../css/index.CM5F9i6p.css"])))=>i.map(i=>d[i]);
var $=Object.defineProperty;var V=(s,e,t)=>e in s?$(s,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):s[e]=t;var a=(s,e,t)=>V(s,typeof e!="symbol"?e+"":e,t);import"./vue.ClgfzGxZ.js";/* empty css               */import{E as H,i as Z,z as q}from"./element-plus.BHdALmn5.js";import{d as j,M as J,u as K,ai as Q,o as M,O as ee,U as te,c as b,a as ie,I as re,au as oe}from"./@vue.Lfky3Lsd.js";import{c as se}from"./pinia.BCCKnU4o.js";import{_ as E}from"./monaco-editor.D3ig2Cuf.js";import{c as ne,a as ae}from"./vue-router.bYO7SHUI.js";import{Q as ce}from"./@element-plus.DY0ir03P.js";import{d as le}from"./dat.gui.kzZ7KUwl.js";import"./lodash-es.CiJSjksT.js";import"./@vueuse.BGoRStkq.js";import"./@popperjs.D9SI2xQl.js";import"./@ctrl.r5W6hzzQ.js";import"./dayjs.Dldw1-ZD.js";import"./@turf.BhhZGEnx.js";import"./point-in-polygon-hao.CVtqB2KT.js";import"./sweepline-intersections.D78iGcFZ.js";import"./geojson-equality-ts.385IDfwq.js";import"./fast-deep-equal.BZWWD7KU.js";import"./d3-geo.B8ycIn1u.js";import"./d3-array.0UpHvbR7.js";import"./concaveman.D4rCrqp7.js";import"./tinyqueue.BpsZqhqS.js";import"./point-in-polygon.BrHNa-um.js";import"./robust-predicates.DbhKlCUI.js";import"./skmeans.Df_G8q9F.js";import"./topojson-client.C_Q_XF1Z.js";import"./topojson-server.BJ5ICLc2.js";import"./polygon-clipping.C7RG_Bzj.js";import"./splaytree.t-pFliWO.js";import"./marchingsquares.DR8wX6S2.js";import"./d3-voronoi.DD4zjRyK.js";import"./async-validator.DKvM95Vc.js";import"./memoize-one.BdPwpGay.js";import"./normalize-wheel-es.B6fDCfyv.js";import"./@floating-ui.8uccrNCM.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))o(r);new MutationObserver(r=>{for(const i of r)if(i.type==="childList")for(const n of i.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&o(n)}).observe(document,{childList:!0,subtree:!0});function t(r){const i={};return r.integrity&&(i.integrity=r.integrity),r.referrerPolicy&&(i.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?i.credentials="include":r.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function o(r){if(r.ep)return;r.ep=!0;const i=t(r);fetch(r.href,i)}})();const ue=j({__name:"App",setup(s){const e="production",o="https://cesium.com/downloads/cesiumjs/releases/1.120/Build/Cesium/";return window.CESIUM_BASE_URL=o,console.log(`模式: ${e}, CESIUM_BASE_URL: ${o}`),(r,i)=>{const n=Q("router-view");return M(),J(K(H),{size:"default"},{default:ee(()=>[te(n)]),_:1})}}}),W=(s,e)=>{const t=s.__vccOpts||s;for(const[o,r]of e)t[o]=r;return t},me=W(ue,[["__scopeId","data-v-6ec92aea"]]),he=se();function de(s){s.use(he)}const ge=()=>E(()=>import("./index.37019a6f.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40]),import.meta.url),fe=()=>E(()=>import("./index.13853179.js"),__vite__mapDeps([41,3,4,38,27,28,5,29,30,31,32,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,33,34,35,36,37,1,2,26,25,42,40]),import.meta.url),pe=[{path:"/",redirect:"/examples"},{path:"/examples",component:fe,name:"examples"},{path:"/examples/preview",component:ge,name:"preview"}],ve=ne({history:ae(),routes:pe,scrollBehavior:()=>({left:0,top:0})}),we=j({name:"IconSvg",props:{value:{type:String,required:!0}}}),ye={key:0,class:"com-icon"},_e={class:"com-icon-svg","aria-hidden":"true"},xe=["xlink:href"];function Le(s,e,t,o,r,i){return s.value.indexOf("#")===0?(M(),b("i",ye,[(M(),b("svg",_e,[ie("use",{"xlink:href":s.value},null,8,xe)]))])):(M(),b("i",{key:1,class:re(s.value)},null,2))}const Ce=W(we,[["render",Le],["__scopeId","data-v-f8504d79"]]),y=window.Cesium,Me=`
  uniform sampler2D colorTexture;
  uniform bool showLightning;
  in vec2 v_textureCoordinates;
  

  float rand(float x)
  {
    return fract(sin(x)*75154.32912);
  }

  // 使用Perlin噪声生成3D伪随机噪声
  float rand3d(vec3 x)
  {
    return fract(375.10297*sin(dot(x,vec3(103.0139,227.0595,31.05914))));
  }
  // 生成1D Perlin噪声
  float noise(float x)
  {
    float i=floor(x);
    float a=rand(i),b=rand(i+1.);
    float f=x-i;
    return mix(a,b,f);
  }

  // 结合多个1D Perlin噪声的八度
  float perlin(float x)
  {
    float r=0.,s=1.,w=1.;
    for(int i=0;i<6;i++){
      s*=2.;
      w*=.5;
      r+=w*noise(s*x);
    }
    return r;
  }
  // 生成3D Perlin噪声
  float noise3d(vec3 x)
  {
    vec3 i=floor(x);
    float i000=rand3d(i+vec3(0.,0.,0.)),i001=rand3d(i+vec3(0.,0.,1.));
    float i010=rand3d(i+vec3(0.,1.,0.)),i011=rand3d(i+vec3(0.,1.,1.));
    float i100=rand3d(i+vec3(1.,0.,0.)),i101=rand3d(i+vec3(1.,0.,1.));
    float i110=rand3d(i+vec3(1.,1.,0.)),i111=rand3d(i+vec3(1.,1.,1.));
    vec3 f=x-i;
    return mix(mix(mix(i000,i001,f.z),mix(i010,i011,f.z),f.y),
    mix(mix(i100,i101,f.z),mix(i110,i111,f.z),f.y),f.x);
  }

  // 结合多个3D Perlin噪声的八度
  float perlin3d(vec3 x)
  {
    float r=0.;
    float w=1.,s=1.;
    for(int i=0;i<5;i++){
      w*=.5;
      s*=2.;
      r+=w*noise3d(s*x);
    }
    return r;
  }

  // 基于Perlin噪声生成闪电形状
  float f(float y)
  {
    float w=.4;// 走向宽度
    return w*(perlin(2.*y)-.5);
  }

  // 绘制闪电，可选择增加厚度
  float plot(vec2 p,float d,bool thicker)
  {
    if(thicker)d+=5.*abs(f(p.y+.001)-f(p.y));
    return smoothstep(d,0.,abs(f(p.y)-p.x));
  }

  // 基于3D Perlin噪声生成云效果
  float cloud(vec2 uv,float speed,float scale,float cover)
  {
    float iTime=czm_frameNumber*.008;
    float c=perlin3d(vec3(uv*scale,iTime*speed*2.));
    return max(0.,c-(1.-cover));
  }

  vec3 render(vec2 uv)
  {
    float iTime=czm_frameNumber*.008;
    float x=iTime+.1;
    float m=.25;// 闪电形状持续时间
    float i=floor(x/m);
    float f=x/m-i;
    float k=.4;// 闪电间隔/频率
    float n=noise(i);
    float t=ceil(n-k);
    float d=max(0.,n-k)/(1.-k);
    float o=ceil(t-f-(1.-d));
    float gt=.1;
    float go=ceil(t-f-(1.-gt));

    float lightning=0.;
    float light=0.;
    float glare=0.;
    if(o==1.){
      vec2 uv2=uv;
      uv2.y+=i*2.;
      float p=(noise(i+10.)-.5)*2.;
      uv2.x-=p;

      float strike=plot(uv2,.01,true);
      float glow=plot(uv2,.04,false);
      float glow2=plot(uv2,1.5,false);

      lightning=strike*.4+glow*.15;

      float h=noise(i+5.);
      lightning*=smoothstep(h,h+.05,uv.y+perlin(1.2*uv.x+4.*h)*.03);
      lightning+=glow2*.3;
      light=smoothstep(5.,0.,abs(uv.x-p));
      glare=go*light;
    }

    vec3 clouds=
    vec3(.5,.7,1.)*mix(.6,.9,cloud(uv,.2,.1,1.))+
    vec3(.7,.8,1.)*.6*cloud(uv*vec2(.5,1.),.06,.8,.8)+
    vec3(.9,.9,1.)*.3*cloud(uv*vec2(.1,1.),.08,5.5,.6)+
    vec3(1.,1.,1.)*.4*cloud(uv*vec2(.1,1.),.07,10.,.5);

    vec3 background=vec3(.8);//背景颜色
    background*=(.2+light*.5);
    if(showLightning == true){
      return vec3(background+lightning+glare);
    }else {
      return vec3(background+glare);
    }
    
  }

  void main()
  {
    vec2 iResolution=czm_viewport.zw;
    vec2 uv=(gl_FragCoord.xy*2.-iResolution.xy)/iResolution.y;

    out_FragColor=vec4(render(uv),1.);

    vec4 sceneColor=texture(colorTexture,v_textureCoordinates);
    out_FragColor=mix(out_FragColor,sceneColor,.5);
  }
`;class Se{constructor(e){a(this,"_viewer");a(this,"showLightning",!1);a(this,"_lighting");this._viewer=e}init(){this._lighting=new y.PostProcessStage({name:"weather_lighting",fragmentShader:Me,uniforms:{fogByDistance:new y.Cartesian4(10,0,1e3,.8),fogColor:y.Color.WHITE,showLightning:()=>this.showLightning}}),this._viewer.scene.postProcessStages.add(this._lighting),this._viewer.scene.postRender.addEventListener(()=>{const e=y.Math.toDegrees(this._viewer.camera.pitch);this.showLightning=e>-15})}destroy(){var e;this.clear(),(e=this._lighting)==null||e.destroy()}clear(){!this._viewer||!this._lighting||this._viewer.scene.postProcessStages.remove(this._lighting)}show(e){e?this.init():this.clear()}}const _=window.Cesium;class be{constructor(e,t){a(this,"viewer");a(this,"angle");a(this,"size");a(this,"speed");a(this,"rainStage");if(!e)throw new Error("no viewer object!");t=t||{},this.angle=_.defaultValue(t.angle,-.6),this.size=_.defaultValue(t.size,.1),this.speed=_.defaultValue(t.speed,1e3),this.viewer=e,this.init()}show(e){this.rainStage.enabled=e}init(){this.rainStage=new _.PostProcessStage({name:"czml_rain",fragmentShader:this.rain(),uniforms:{angle:()=>this.angle,size:()=>this.size,speed:()=>this.speed}}),this.viewer.scene.postProcessStages.add(this.rainStage)}destroy(){!this.viewer||!this.rainStage||this.viewer.scene.postProcessStages.remove(this.rainStage)}rain(){return`uniform sampler2D colorTexture;
              varying vec2 v_textureCoordinates;
              uniform float angle;
              uniform float size;
              uniform float speed;
              float hash(float x){
                  return fract(sin(x*133.3)*13.13);
          }
          void main(void){
              float time = czm_frameNumber / speed;
              vec2 resolution = czm_viewport.zw;
              vec2 uv=(gl_FragCoord.xy*2.-resolution.xy)/min(resolution.x,resolution.y);
              vec3 c=vec3(.6,.7,.8);
              float a=angle;
              float si=sin(a),co=cos(a);
              uv*=mat2(co,-si,si,co);
              uv*=length(uv+vec2(0,4.9))*size + 1.;
              float v=1.-sin(hash(floor(uv.x*100.))*2.);
              float b=clamp(abs(sin(20.*time*v+uv.y*(5./(2.+v))))-.95,0.,1.)*20.;
              c*=v*b; 
              gl_FragColor = mix(texture2D(colorTexture, v_textureCoordinates), vec4(c,1), 0.5);  
          }
           `}}const Re=window.Cesium.Cartesian4,Pe=window.Cesium.Color,Ue=window.Cesium.PostProcessStage;class Be{constructor(e){a(this,"viewer");a(this,"collection");a(this,"postProcessState");a(this,"_fogByDistance",{near:100,nearValue:.35,far:4e3,farValue:.9});a(this,"_color",new Pe(1,1,1,1));a(this,"_visibility",.4);this.viewer=e,this.collection=e.scene.postProcessStages}set fogByDistance(e){this._fogByDistance=e}get fogByDistance(){return this._fogByDistance}set color(e){this._color=e}get color(){return this._color}get visibility(){return this._visibility}set visibility(e){this._visibility=e}_createPostProcessStage(){var e,t,o,r;this.postProcessState=new Ue({name:"czm_fog",fragmentShader:this._getFs(),uniforms:{fogColor:()=>this._color,visibility:()=>this._visibility,fogByDistance:new Re(((e=this._fogByDistance)==null?void 0:e.near)||10,((t=this._fogByDistance)==null?void 0:t.nearValue)||0,((o=this._fogByDistance)==null?void 0:o.far)||200,((r=this._fogByDistance)==null?void 0:r.farValue)||1)}}),this.collection.add(this.postProcessState)}_getFs(){return`float getDistance(sampler2D depthTexture, vec2 texCoords)
              {
                  float depth = czm_unpackDepth(texture(depthTexture, texCoords));
                  if (depth == 0.0) {
                      return czm_infinity;
                  }
                  vec4 eyeCoordinate = czm_windowToEyeCoordinates(gl_FragCoord.xy, depth);
                  return -eyeCoordinate.z / eyeCoordinate.w;
              }
              //根据距离，在中间进行插值
              float interpolateByDistance(vec4 nearFarScalar, float distance)
              {
                  //根据常识，雾应该是距离远，越看不清，近距离内的物体可以看清
                  //因此近距离alpha=0，远距离的alpha=1.0
                  //本例中设置可见度为200米
                  //雾特效的起始距离
                  float startDistance = nearFarScalar.x;
                  //雾特效的起始alpha值
                  float startValue = nearFarScalar.y;
                  //雾特效的结束距离
                  float endDistance = nearFarScalar.z;
                  //雾特效的结束alpha值
                  float endValue = nearFarScalar.w;
                  //根据每段距离占总长度的占比，插值alpha，距离越远，alpha值越大。插值范围0,1。
                  float t = clamp((distance - startDistance) / (endDistance - startDistance), 0.0, 1.0);
                  return mix(startValue, endValue, t);
              }
              vec4 alphaBlend(vec4 sourceColor, vec4 destinationColor)
              {
                  return sourceColor * vec4(sourceColor.aaa, 1.0) + destinationColor * (1.0 - sourceColor.a);
              }
              uniform sampler2D colorTexture;
              uniform sampler2D depthTexture;
              uniform vec4 fogByDistance;
              uniform vec4 fogColor;
              in vec2 v_textureCoordinates;
              void main(void)
              {
                  //获取地物距相机的距离
                  float distance = getDistance(depthTexture, v_textureCoordinates);
                  //获取场景原本的纹理颜色
                  vec4 sceneColor = texture(colorTexture, v_textureCoordinates);
                  //根据距离，对alpha进行插值
                  float blendAmount = interpolateByDistance(fogByDistance, distance);
                  //将alpha变化值代入雾的原始颜色中，并将雾与场景原始纹理进行融合
                  vec4 finalFogColor = vec4(fogColor.rgb, fogColor.a * blendAmount);
                  out_FragColor = alphaBlend(finalFogColor, sceneColor);
              }`}open(){const e=this.viewer.scene;this.postProcessState||(this._createPostProcessStage(),e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.7,e.fog.density=5e-4,e.fog.minimumBrightness=.03)}close(){const e=this.viewer.scene;this.postProcessState&&(this.collection.remove(this.postProcessState),this.postProcessState=void 0,e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.4,e.fog.density=2e-4,e.fog.minimumBrightness=.03)}}const ke=window.Cesium.PostProcessStage;class De{constructor(e){a(this,"viewer");a(this,"collection");a(this,"speed",80);a(this,"size",.02);a(this,"postProcessState");this.viewer=e,this.collection=e.scene.postProcessStages}_createPostProcessStage(){this.postProcessState=new ke({name:"czm_snow",fragmentShader:this._getFs(),uniforms:{speed:()=>this.speed,size:()=>this.size}}),this.collection.add(this.postProcessState)}_getFs(){return`uniform sampler2D colorTexture;
    varying vec2 v_textureCoordinates;
    uniform float speed;
    uniform float size;
    float snow(vec2 uv,float scale)
    {
        float time = czm_frameNumber / speed;
        float w=smoothstep(1.,0.,-uv.y*(scale/10.));if(w<.1)return 0.;
        uv+=time/scale;uv.y+=time*2./scale;uv.x+=sin(uv.y+time*.5)/scale;
        uv*=scale;vec2 s=floor(uv),f=fract(uv),p;float k=3.,d;
        p=.5+.35*sin(11.*fract(sin((s+p+scale)*mat2(7,3,6,5))*5.))-f;d=length(p);k=min(d,k);
        k=smoothstep(0.,k,sin(f.x+f.y)*size);
        return k*w;
    }
    void main(void){
        vec2 resolution = czm_viewport.zw;
        vec2 uv=(gl_FragCoord.xy*2.-resolution.xy)/min(resolution.x,resolution.y);
        vec3 finalColor=vec3(0);
        float c = 0.0;
        c+=snow(uv,30.)*.0;
        c+=snow(uv,20.)*.0;
        c+=snow(uv,15.)*.0;
        c+=snow(uv,10.);
        c+=snow(uv,8.);
        c+=snow(uv,6.);
        c+=snow(uv,5.);
        finalColor=(vec3(c)); 
        gl_FragColor = mix(texture2D(colorTexture, v_textureCoordinates), vec4(finalColor,1), 0.5); 
    }
`}open(){const e=this.viewer.scene;this.postProcessState||(this._createPostProcessStage(),e.skyAtmosphere.hueShift=-.8,e.skyAtmosphere.saturationShift=-.7,e.skyAtmosphere.brightnessShift=-.33,e.fog.density=.001,e.fog.minimumBrightness=.8)}close(){const e=this.viewer.scene;this.postProcessState&&(this.collection.remove(this.postProcessState),this.postProcessState=void 0,e.skyAtmosphere.hueShift=0,e.skyAtmosphere.saturationShift=0,e.skyAtmosphere.brightnessShift=.4,e.fog.density=2e-4,e.fog.minimumBrightness=.03)}}const l=window.Cesium,g=l,Te=`
    uniform samplerCube u_cubeMap;
    varying vec3 v_texCoord;
    void main()
    {
      vec4 color = textureCube(u_cubeMap, normalize(v_texCoord));
      gl_FragColor = vec4(czm_gammaCorrect(color).rgb, czm_morphTime);
    }
  `,ze=`
    attribute vec3 position; 
    varying vec3 v_texCoord;
    uniform mat3 u_rotateMatrix;
    void main()
    {
      vec3 p = czm_viewRotation * u_rotateMatrix * (czm_temeToPseudoFixed * (czm_entireFrustum.y * position));
      gl_Position = czm_projection * vec4(p, 1.0);
      v_texCoord = position.xyz;
    }
  `;class Ie{constructor(e,t){a(this,"viewer");a(this,"sources");a(this,"show");a(this,"_sources");a(this,"_command");a(this,"_cubeMap");a(this,"defaultSkyBox");a(this,"skyListener");a(this,"_useHdr");a(this,"_attributeLocations");this.viewer=e,this.sources=t.sources,this._sources=void 0,this.show=l.defaultValue(t.show,!0);const o=g.DrawCommand;this._command=new o({modelMatrix:l.Matrix4.clone(l.Matrix4.IDENTITY),owner:this}),this._cubeMap=void 0,this._attributeLocations=void 0,this._useHdr=void 0,this.skyListener=null,this.defaultSkyBox=e.scene.skyBox}renderer(e){this.skyListener=()=>{const t=this.viewer.scene.camera.positionCartographic.height,o=22e4,r=15e4,i=12e4,n=1e4,c=this.viewer.scene.skyAtmosphere;if(t<o&&l.defined(e)){let m=(t-i)/(o-i);m>1?m=1:m<0&&(m=0);let d=(t-i)/(r-i);d>1?d=1:d<0&&(d=0),e.alpha=1-d,t>i?(c.show=!0,c.alpha=m,this.viewer.scene.skyBox=e):this.viewer.scene.skyAtmosphere.show=!1}else c.alpha=1,this.viewer.scene.skyBox=this.defaultSkyBox;const u=this.viewer.scene.screenSpaceCameraController;if(this.viewer.scene.skyBox!==this.defaultSkyBox)t>i-2*n&&t<r+3*n?u.zoomFactor=.4:u.zoomFactor=5;else{const m=this.viewer.scene.skyBox;m.alpha=1;const d=this.viewer.scene.skyAtmosphere;d.alpha=1,u.zoomFactor=5}},this.viewer.scene.postRender.addEventListener(this.skyListener)}update(e,t){if(!this.show||e.mode!==l.SceneMode.SCENE3D&&e.mode!==l.SceneMode.MORPHING||!e.passes.render)return;const o=e.context;if(this._sources!==this.sources){this._sources=this.sources;const i=this.sources;if(!l.defined(i.positiveX)||!l.defined(i.negativeX)||!l.defined(i.positiveY)||!l.defined(i.negativeY)||!l.defined(i.positiveZ)||!l.defined(i.negativeZ))throw new l.DeveloperError("this.sources is required and must have positiveX, negativeX, positiveY, negativeY, positiveZ, and negativeZ properties.");if(typeof i.positiveX!=typeof i.negativeX||typeof i.positiveX!=typeof i.positiveY||typeof i.positiveX!=typeof i.negativeY||typeof i.positiveX!=typeof i.positiveZ||typeof i.positiveX!=typeof i.negativeZ)throw new l.DeveloperError("this.sources properties must all be the same type.");typeof i.positiveX=="string"?g.loadCubeMap(o,this._sources).then(n=>{this._cubeMap=this._cubeMap&&this._cubeMap.destroy(),this._cubeMap=n}):(this._cubeMap=this._cubeMap&&this._cubeMap.destroy(),this._cubeMap=new g.CubeMap({context:o,source:i}))}const r=this._command;if(r.modelMatrix=l.Transforms.eastNorthUpToFixedFrame(e.camera._positionWC),!l.defined(r.vertexArray)){r.uniformMap={u_cubeMap:()=>this._cubeMap,u_rotateMatrix:function(){return l.Matrix4.getRotation(r.modelMatrix,new l.Matrix3)}};const i=l.BoxGeometry.createGeometry(l.BoxGeometry.fromDimensions({dimensions:new l.Cartesian3(2,2,2),vertexFormat:l.VertexFormat.POSITION_ONLY})),n=this._attributeLocations=l.GeometryPipeline.createAttributeLocations(i);r.vertexArray=g.VertexArray.fromGeometry({context:o,geometry:i,attributeLocations:n,bufferUsage:g.BufferUsage._DRAW}),r.renderState=g.RenderState.fromCache({blending:l.BlendingState.ALPHA_BLEND})}if(!l.defined(r.shaderProgram)||this._useHdr!==t){const i=new g.ShaderSource({defines:[t?"HDR":""],sources:[Te]});r.shaderProgram=g.ShaderProgram.fromCache({context:o,vertexShaderSource:ze,fragmentShaderSource:i,attributeLocations:this._attributeLocations}),this._useHdr=t}if(l.defined(this._cubeMap))return r}destroy(){const e=this._command;e.vertexArray=e.vertexArray&&e.vertexArray.destroy(),e.shaderProgram=e.shaderProgram&&e.shaderProgram.destroy(),this._cubeMap=this._cubeMap&&this._cubeMap.destroy(),this.viewer.scene.skyBox=this.defaultSkyBox,this.skyListener&&this.viewer.scene.postRender.removeEventListener(this.skyListener)}}const h=Math.PI,S=Math.PI*3e3/180,B=6378245,k=.006693421622965943,Fe=(s,e)=>{const t=+s-.0065,o=+e-.006,r=Math.sqrt(t*t+o*o)-2e-5*Math.sin(o*S),i=Math.atan2(o,t)-3e-6*Math.cos(t*S),n=r*Math.cos(i),c=r*Math.sin(i);return[n,c]},Ae=(s,e)=>{e=+e,s=+s;const t=Math.sqrt(s*s+e*e)+2e-5*Math.sin(e*S),o=Math.atan2(e,s)+3e-6*Math.cos(s*S),r=t*Math.cos(o)+.0065,i=t*Math.sin(o)+.006;return[r,i]},N=(s,e)=>{if(e=+e,s=+s,O(s,e))return[s,e];{const t=X(s,e);return[s+t[0],e+t[1]]}},G=(s,e)=>{if(e=+e,s=+s,O(s,e))return[s,e];{const t=X(s,e),o=s+t[0],r=e+t[1];return[s*2-o,e*2-r]}},X=(s,e)=>{let t=je(s-105,e-35),o=Ee(s-105,e-35);const r=e/180*h;let i=Math.sin(r);i=1-k*i*i;const n=Math.sqrt(i);return t=t*180/(B/n*Math.cos(r)*h),o=o*180/(B*(1-k)/(i*n)*h),[t,o]},je=(s,e)=>{e=+e,s=+s;let t=300+s+2*e+.1*s*s+.1*s*e+.1*Math.sqrt(Math.abs(s));return t+=(20*Math.sin(6*s*h)+20*Math.sin(2*s*h))*2/3,t+=(20*Math.sin(s*h)+40*Math.sin(s/3*h))*2/3,t+=(150*Math.sin(s/12*h)+300*Math.sin(s/30*h))*2/3,t},Ee=(s,e)=>{e=+e,s=+s;let t=-100+2*s+3*e+.2*e*e+.1*s*e+.2*Math.sqrt(Math.abs(s));return t+=(20*Math.sin(6*s*h)+20*Math.sin(2*s*h))*2/3,t+=(20*Math.sin(e*h)+40*Math.sin(e/3*h))*2/3,t+=(160*Math.sin(e/12*h)+320*Math.sin(e*h/30))*2/3,t},O=(s,e)=>(e=+e,s=+s,!(s>73.66&&s<135.05&&e>3.86&&e<53.55));window.Cesium.Cartesian3;window.Cesium.Ellipsoid;const Y=window.Cesium.Math;window.Cesium.Cartographic;const We=window.Cesium.WebMercatorProjection;window.Cesium.SceneMode;window.Cesium.SceneTransforms;new We;const p=s=>Y.toDegrees(s),v=s=>Y.toRadians(s),Ne=637099681e-2,D=[1289059486e-2,836237787e-2,5591021,348198983e-2,167804312e-2,0],x=[75,60,45,30,15,0],Ge=[[1410526172116255e-23,898305509648872e-20,-1.9939833816331,200.9824383106796,-187.2403703815547,91.6087516669843,-23.38765649603339,2.57121317296198,-.03801003308653,173379812e-1],[-7435856389565537e-24,8983055097726239e-21,-.78625201886289,96.32687599759846,-1.85204757529826,-59.36935905485877,47.40033549296737,-16.50741931063887,2.28786674699375,1026014486e-2],[-3030883460898826e-23,898305509983578e-20,.30071316287616,59.74293618442277,7.357984074871,-25.38371002664745,13.45380521110908,-3.29883767235584,.32710905363475,685681737e-2],[-1981981304930552e-23,8983055099779535e-21,.03278182852591,40.31678527705744,.65659298677277,-4.44255534477492,.85341911805263,.12923347998204,-.04625736007561,448277706e-2],[309191371068437e-23,8983055096812155e-21,6995724062e-14,23.10934304144901,-.00023663490511,-.6321817810242,-.00663494467273,.03430082397953,-.00466043876332,25551644e-1],[2890871144776878e-24,8983055095805407e-21,-3068298e-14,7.47137025468032,-353937994e-14,-.02145144861037,-1234426596e-14,.00010322952773,-323890364e-14,826088.5]],T=[[-.0015702102444,111320.7020616939,0x60e374c3105a3,-0x24bb4115e2e164,0x5cc55543bb0ae8,-0x7ce070193f3784,0x5e7ca61ddf8150,-0x261a578d8b24d0,0x665d60f3742ca,82.5],[.0008277824516172526,111320.7020463578,64779557466716e-5,-4082003173641316e-6,1077490566351142e-5,-1517187553151559e-5,1205306533862167e-5,-5124939663577472e-6,9133119359512032e-7,67.5],[.00337398766765,111320.7020202162,4481351045890365e-9,-2339375119931662e-8,7968221547186455e-8,-1159649932797253e-7,9723671115602145e-8,-4366194633752821e-8,8477230501135234e-9,52.5],[.00220636496208,111320.7020209128,51751.86112841131,3796837749470245e-9,992013.7397791013,-122195221711287e-8,1340652697009075e-9,-620943.6990984312,144416.9293806241,37.5],[-.0003441963504368392,111320.7020576856,278.2353980772752,2485758690035394e-9,6070.750963243378,54821.18345352118,9540.606633304236,-2710.55326746645,1405.483844121726,22.5],[-.0003218135878613132,111320.7020701615,.00369383431289,823725.6402795718,.46104986909093,2351.343141331292,1.58060784298199,8.77738589078284,.37238884252424,7.45]];class Xe{constructor(){a(this,"isWgs84",!1)}getDistanceByMC(e,t){if(!e||!t)return 0;const o=this.convertMC2LL(e);if(!o)return 0;const r=this.toRadians(o.longitude),i=this.toRadians(o.latitude),n=this.convertMC2LL(t);if(!n)return 0;const c=this.toRadians(n.longitude),u=this.toRadians(n.latitude);return this.getDistance(r,c,i,u)}getDistanceByLL(e,t){if(!e||!t)return 0;e.longitude=this.getLoop(e.longitude,-180,180),e.latitude=this.getRange(e.latitude,-74,74),t.longitude=this.getLoop(t.longitude,-180,180),t.latitude=this.getRange(t.latitude,-74,74);const o=this.toRadians(e.longitude),r=this.toRadians(e.latitude),i=this.toRadians(t.longitude),n=this.toRadians(t.latitude);return this.getDistance(o,i,r,n)}convertMC2LL(e){if(!e)return{longitude:0,latitude:0};let t={longitude:0,latitude:0};if(this.isWgs84){t.longitude=e.longitude/2003750834e-2*180;const i=e.latitude/2003750834e-2*180;return t.latitude=180/Math.PI*(2*Math.atan(Math.exp(i*Math.PI/180))-Math.PI/2),{longitude:Number.parseFloat(t.longitude.toFixed(8)),latitude:Number.parseFloat(t.latitude.toFixed(8))}}const o={longitude:Math.abs(e.longitude),latitude:Math.abs(e.latitude)};let r=[];for(let i=0;i<D.length;i++)if(o.latitude>=D[i]){r=Ge[i];break}return t=this.convertor(e,r),{longitude:Number.parseFloat(t.longitude.toFixed(8)),latitude:Number.parseFloat(t.latitude.toFixed(8))}}convertLL2MC(e){if(!e)return{longitude:0,latitude:0};if(e.longitude>180||e.longitude<-180||e.latitude>90||e.latitude<-90)return e;if(this.isWgs84){const i={longitude:0,latitude:0},n=6378137;i.longitude=e.longitude*Math.PI/180*n;const c=e.latitude*Math.PI/180;return i.latitude=n/2*Math.log((1+Math.sin(c))/(1-Math.sin(c))),{longitude:parseFloat(i.longitude.toFixed(2)),latitude:parseFloat(i.latitude.toFixed(2))}}e.longitude=this.getLoop(e.longitude,-180,180),e.latitude=this.getRange(e.latitude,-74,74);const t={longitude:e.longitude,latitude:e.latitude};let o=[];for(let i=0;i<x.length;i++)if(t.latitude>=x[i]){o=T[i];break}if(!o.length){for(let i=0;i<x.length;i++)if(t.latitude<=-x[i]){o=T[i];break}}const r=this.convertor(e,o);return{longitude:parseFloat(r.longitude.toFixed(2)),latitude:parseFloat(r.latitude.toFixed(2))}}convertor(e,t){if(!e||!t)return{longitude:0,latitude:0};let o=t[0]+t[1]*Math.abs(e.longitude);const r=Math.abs(e.latitude)/t[9];let i=t[2]+t[3]*r+t[4]*r*r+t[5]*r*r*r+t[6]*r*r*r*r+t[7]*r*r*r*r*r+t[8]*r*r*r*r*r*r;return o*=e.longitude<0?-1:1,i*=e.latitude<0?-1:1,{longitude:o,latitude:i}}getDistance(e,t,o,r){return Ne*Math.acos(Math.sin(o)*Math.sin(r)+Math.cos(o)*Math.cos(r)*Math.cos(t-e))}toRadians(e){return Math.PI*e/180}toDegrees(e){return 180*e/Math.PI}getRange(e,t,o){return t!=null&&(e=Math.max(e,t)),o!=null&&(e=Math.min(e,o)),e}getLoop(e,t,o){for(;e>o;)e-=o-t;for(;e<t;)e+=o-t;return e}lngLatToMercator(e){return this.convertLL2MC(e)}lngLatToPoint(e){const t=this.convertLL2MC(e);return{x:t.longitude,y:t.latitude}}mercatorToLngLat(e){return this.convertMC2LL(e)}pointToLngLat(e){const t={longitude:e.x,latitude:e.y};return this.convertMC2LL(t)}pointToPixel(e,t,o,r){if(!e)return{x:0,y:0};e=this.lngLatToMercator(e);const i=this.getZoomUnits(t),n=Math.round((e.longitude-o.longitude)/i+r.width/2),c=Math.round((o.latitude-e.latitude)/i+r.height/2);return{x:n,y:c}}pixelToPoint(e,t,o,r){if(!e)return{longitude:0,latitude:0};const i=this.getZoomUnits(t),n=o.longitude+i*(e.x-r.width/2),c=o.latitude-i*(e.y-r.height/2),u={longitude:n,latitude:c};return this.mercatorToLngLat(u)}getZoomUnits(e){return Math.pow(2,18-e)}}const z=window.Cesium.Cartesian2,Oe=window.Cesium.Cartographic,I=window.Cesium.Rectangle,R=window.Cesium.defined,Ye=window.Cesium.WebMercatorTilingScheme;class $e extends Ye{constructor(e){super(e);const t=new Xe;this._projection.project=o=>{const r=N(p(o.longitude),p(o.latitude)),i=Ae(r[0],r[1]),n=[];n[0]=Math.min(i[0],180),n[0]=Math.max(n[0],-180),n[1]=Math.min(i[1],74.000022),n[1]=Math.max(n[1],-71.988531);const c=t.lngLatToPoint({longitude:n[0],latitude:n[1]});return new z(c.x,c.y)},this._projection.unproject=o=>{const r=t.mercatorToLngLat({longitude:o.x,latitude:o.y});let i=Fe(r.longitude,r.latitude);return i=G(i[0],i[1]),new Oe(v(i[0]),v(i[1]))},this.resolutions=(e==null?void 0:e.resolutions)||[]}tileXYToNativeRectangle(e,t,o,r){const i=this.resolutions[o],n=e*i,c=(e+1)*i,u=((t=-t)+1)*i,m=t*i;return R(r)?(r.west=n,r.south=m,r.east=c,r.north=u,r):new I(n,m,c,u)}positionToTileXY(e,t,o){const r=this._rectangle;if(!I.contains(r,e))return;const n=this._projection.project(e);if(!R(n))return;const c=this.resolutions[t],u=Math.floor(n.x/c),m=-Math.floor(n.y/c);return R(o)?(o.x=u,o.y=m,o):new z(u,m)}}const L=window.Cesium.Cartesian2,Ve=window.Cesium.WebMercatorTilingScheme,f=window.Cesium.DeveloperError,He=window.Cesium.ImageryProvider,Ze="http://shangetu{s}.map.bdimg.com/it/u=x={x};y={y};z={z};v=009;type=sate&fm=46",qe="http://its.map.baidu.com:8002/traffic/TrafficTileService?time={time}&label={labelStyle}&v=016&level={z}&x={x}&y={y}&scaler=2";class Je{constructor(e){a(this,"_url");a(this,"_labelStyle");a(this,"_tileWidth");a(this,"_tileHeight");a(this,"_maximumLevel");a(this,"_crs");a(this,"_tilingScheme");a(this,"_rectangle");a(this,"_credit");a(this,"_token");a(this,"_style");a(this,"_scaler");if(this._scaler=e.scaler??1,this._url=this.getUrl(e.style),this._labelStyle=e.labelStyle||"web2D",this._tileWidth=256,this._tileHeight=256,this._maximumLevel=18,this._crs=e.crs||"BD09",e.crs==="WGS84"){const t=[];for(let o=0;o<19;o++)t[o]=256*Math.pow(2,18-o);this._tilingScheme=new $e({resolutions:t,rectangleSouthwestInMeters:new L(-2003772637e-2,-1247410417e-2),rectangleNortheastInMeters:new L(2003772637e-2,1247410417e-2)})}else this._tilingScheme=new Ve({rectangleSouthwestInMeters:new L(-33554054,-33746824),rectangleNortheastInMeters:new L(33554054,33746824)});this._rectangle=this._tilingScheme.rectangle,this._token=void 0,this._style=e.style||"normal"}get url(){return this._url}get token(){return this._token}get tileWidth(){if(!this.ready)throw new f("tileWidth must not be called before the imagery provider is ready.");return this._tileWidth}get tileHeight(){if(!this.ready)throw new f("tileHeight must not be called before the imagery provider is ready.");return this._tileHeight}get maximumLevel(){if(!this.ready)throw new f("maximumLevel must not be called before the imagery provider is ready.");return this._maximumLevel}get minimumLevel(){if(!this.ready)throw new f("minimumLevel must not be called before the imagery provider is ready.");return 0}get tilingScheme(){if(!this.ready)throw new f("tilingScheme must not be called before the imagery provider is ready.");return this._tilingScheme}get rectangle(){if(!this.ready)throw new f("rectangle must not be called before the imagery provider is ready.");return this._rectangle}get ready(){return!!this._url}get credit(){return this._credit}get hasAlphaChannel(){return!0}getUrl(e){return e==="img"?Ze:e==="vec"?`http://online{s}.map.bdimg.com/onlinelabel/?qt=tile&x={x}&y={y}&z={z}&styles=pl&scaler=${this._scaler}&p=1`:e==="traffic"?qe:"http://api{s}.map.bdimg.com/customimage/tile?&x={x}&y={y}&z={z}&scale=1&customid="+this._style}requestImage(e,t,o){if(!this.ready)throw new f("requestImage must not be called before the imagery provider is ready.");const r=this._tilingScheme.getNumberOfXTilesAtLevel(o),i=this._tilingScheme.getNumberOfYTilesAtLevel(o);let n=this._url.replace("{z}",o+"").replace("{s}",String(1)).replace("{style}",this._style).replace("{labelStyle}",this._labelStyle).replace("{time}",String(new Date().getTime()));return this._crs==="WGS84"?n=n.replace("{x}",String(e)).replace("{y}",String(-t)):n=n.replace("{x}",String(e-r/2)).replace("{y}",String(i/2-t-1)),He.loadImage(this,n)}}const Ke=window.Cesium.Cartesian2,F=window.Cesium.Cartographic,Qe=window.Cesium.WebMercatorProjection,et=window.Cesium.WebMercatorTilingScheme;class tt extends et{constructor(e){super(e);const t=new Qe;this._projection.project=(o,r)=>{const i=N(p(o.longitude),p(o.latitude));return r=t.project(new F(v(i[0]),v(i[1]))),new Ke(r.x,r.y)},this._projection.unproject=function(o,r){const i=t.unproject(o),n=G(p(i.longitude),p(i.latitude));return r=new F(v(n[0]),v(n[1])),r}}}const it=window.Cesium.UrlTemplateImageryProvider,rt="https://webst{s}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}",ot="http://webrd{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}",st="https://webst{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}";class nt extends it{constructor(e){e.url=(e==null?void 0:e.style)==="img"?rt:(e==null?void 0:e.style)==="cva"?st:ot,e.subdomains=e.subdomains||["01","02","03","04"],e.crs==="WGS84"&&(e.tilingScheme=new tt),super(e)}}const at=window.Cesium.UrlTemplateImageryProvider,A={img:"//p{s}.map.gtimg.com/sateTiles/{z}/{sx}/{sy}/{x}_{reverseY}.jpg?version=400",elec:"//rt{s}.map.gtimg.com/tile?z={z}&x={x}&y={reverseY}&styleid={style}&scene=0&version=347"};class ct extends at{constructor(e){const t=e.url||[e.protocol||"",A[e.style]||A.elec].join("");e.url=t.replace("{style}",e.style||1),e.subdomains=e.subdomains||["1","2","3"],e.style==="img"&&(e.customTags={sx:(o,r,i,n)=>r>>4,sy:(o,r,i,n)=>(1<<n)-i>>4}),super(e)}}const C=window.Cesium;class lt{constructor(e){a(this,"options");a(this,"scales84");a(this,"scalesweb");a(this,"delegate");this.options=Object.assign({},{minimumLevel:0,maximumLevel:18,epsgcode:3857,token:""},e),this.scales84=[338032714321e-20,676065428641e-20,1352130857282e-20,2704261714564e-20,5408523429128e-20,10817046858257e-20,21634093716514e-20,43268187433028e-20,86536374866056e-20,173072749732112e-20,346145499464224e-20,692290998928448e-20,13845819978568952e-21,27691639957137904e-21,5538327991427581e-20,.00011076655982855162,.00022153311965710323,.00044306623931420646,.0008861324786284129,.0017722649572568258,.0035445299145136517,.007089059829027303],this.scalesweb=[16901635716e-19,338032714321e-20,676065428641e-20,1352130857282e-20,2704261714564e-20,5408523429128e-20,10817046858257e-20,21634093716514e-20,43268187433028e-20,86536374866056e-20,173072749732112e-20,346145499464224e-20,692290998928448e-20,13845819978568952e-21,27691639957137904e-21,5538327991427581e-20,.00011076655982855162,.00022153311965710323,.00044306623931420646,.0008861324786284129,.0017722649572568258,.0035445299145136517,.007089059829027303],this.delegate=this.createSuperMapLayer(this.options)}createSuperMapLayer(e){const t=C.Rectangle.fromDegrees(-180,-90,180,90),o=e.epsgcode;let r,i=0,n=22,c=0,u=0;o===4326&&(r=new C.GeographicTilingScheme({numberOfLevelZeroTilesX:2,numberOfLevelZeroTilesY:1}),c=-180,u=90,e.minimumLevel!==void 0?i=e.minimumLevel:i=0,e.maximumLevel!==void 0?n=e.maximumLevel:n=22),o===3857&&(r=new C.WebMercatorTilingScheme,c=-2003750834e-2,u=2003750834e-2,e.minimumLevel!==void 0?(console.log("not undefined"),i=e.minimumLevel):i=0,e.maximumLevel!==void 0?n=e.maximumLevel:n=22);const m=`{"x":${c},"y":${u}}`,d=`${this.options.url}/tileImage.png?transparent=true&cacheEnabled=true&width=256&height=256&x={x}&y={y}&scale={scale}&redirect=false&overlapDisplayed=false&origin={origin}`;return new C.UrlTemplateImageryProvider({url:d,rectangle:t,minimumLevel:i||0,maximumLevel:n||22,tilingScheme:r,customTags:{scale:(yt,_t,xt,U)=>{if(o===4326)return this.scales84[U];if(o===3857)return this.scalesweb[U]},origin:()=>m}})}}const ut=new URL(""+new URL("../img/world_b.CKToTiVD.jpg",import.meta.url).href,import.meta.url).href,mt=new URL(""+new URL("../img/world_img.BGGjUUzF.jpg",import.meta.url).href,import.meta.url).href,ht=new URL(""+new URL("../img/backGroundImg.CHcdoOpt.jpg",import.meta.url).href,import.meta.url).href,dt={positiveX:new URL(""+new URL("../img/Right.DvICu_nL.jpg",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.Beb91ZrI.jpg",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.CNsTSgXm.jpg",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.Cc3mBCf3.jpg",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.Bw1YxhIs.jpg",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.BvGcIg6o.jpg",import.meta.url).href,import.meta.url).href},gt={positiveX:new URL(""+new URL("../img/Right.DdlANBEa.jpg",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.B8rfaA0r.jpg",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.DPEAmiXi.jpg",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.DJrVM9dN.jpg",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.CMCoYR6m.jpg",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.lnNfcNjB.jpg",import.meta.url).href,import.meta.url).href},ft={positiveX:new URL(""+new URL("../img/Right.D5T4YmHC.png",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.CvRmAvgL.png",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.2o9Lxxyg.png",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.C49sX_sW.png",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.B-I1Cg_a.png",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.CRKe6wcu.png",import.meta.url).href,import.meta.url).href},pt={positiveX:new URL(""+new URL("../img/Right.DfXBh-Je.jpg",import.meta.url).href,import.meta.url).href,negativeX:new URL(""+new URL("../img/Left.DAu_0SLw.jpg",import.meta.url).href,import.meta.url).href,positiveY:new URL(""+new URL("../img/Front.Cu5ZW8wg.jpg",import.meta.url).href,import.meta.url).href,negativeY:new URL(""+new URL("../img/Back.DzIrvXSv.jpg",import.meta.url).href,import.meta.url).href,positiveZ:new URL(""+new URL("../img/Up.CPesry4o.jpg",import.meta.url).href,import.meta.url).href,negativeZ:new URL(""+new URL("../img/Down.BHPfJ1nb.jpg",import.meta.url).href,import.meta.url).href},vt={dat:le,Lightning:Se,Rain:be,Fog:Be,Snow:De,GroundSkyBox:Ie,BaiduImageryProvider:Je,AmapImageryProvider:nt,TencentImageryProvider:ct,SuperMapImagryProvider:lt,BaseMapWorld_Blue:ut,BaseMapWorld_Image:mt,SceneBackGroundImg:ht,GroundSkyBoxBlueSky:dt,GroundSkyBoxSun:gt,GroundSkyBoxSunsetGlow:ft,GroundSkyBoxNight:pt};for(const[s,e]of Object.entries(vt))Reflect.defineProperty(window,s,{value:e});const P=document.createElement("link");P.rel="stylesheet";P.href="//at.alicdn.com/t/c/font_4702543_kgiwod8u1v.css";document.head.appendChild(P);const w=oe(me);de(w);for(const[s,e]of Object.entries(ce))w.component(s,e);w.component("IconSvg",Ce);w.use(Z,{locale:q});w.use(ve).mount("#app");export{W as _};
